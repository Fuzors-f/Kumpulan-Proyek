<?php require_once("Connection.php");?>
<head>
        <script src="jquery/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="materialize/js/materialize.min.js"></script>
        <style>
            .back{
                background-color: gray;
                color: white;
                width : 80px;
                height: 40px;
                font-size: 12pt;
                text-align: center;
                margin: 15px;
                padding:10px;
                border: 2px solid gray;
            }
            .back:hover{
                background-color: white;
                border: 2px solid white;
                color: black;
            }
        </style>
</head>
<body>
    <div class="row">
            <?php
                $id = $_POST['id'];
                $ressultnama ="";
                $query1=mysqli_query($conn,"SELECT testimoni_nama from testimoni where testimoni_id= $id");
                foreach($query1 as $key=>$data){
                    $ressultnama = $data["testimoni_nama"];
                }
                $query = mysqli_query($conn,"SELECT testimoni_text from testimoni_bahasa WHERE testimoni_bahasa_id = $id");
                $result = mysqli_fetch_array($query);
                echo "<div class='container' style='margin-left:-20px;'>";
                echo "<h1>".$ressultnama."</h1>";
                echo "<hr style='border:2px solid gray'>";
                echo "<div style='padding:10px;margin:10px;font-size:16pt'><p>".$result[0]."</p></div>";
                echo "<button class='back' id='bt'> BACK </button>";
                echo "</div>";

            ?>
    </div>
</body>
<script>
    $('.back').click(function (){
        $('#cont').html("");
        $('#cont').load("ListTestimoni.php");
    })
</script>