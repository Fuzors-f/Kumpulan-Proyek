<?php
    require_once("Connection.php");

    $judul = $_POST["judul"];


    $query2 = "INSERT INTO tag VALUES('',1)";
    
    if($conn->query($query2)== true){
        $id ="";
        $res  = mysqli_query($conn, "select * from tag order by tag_id"); //LHOOOO
        foreach($res as $key=>$data){
            $id = $data['tag_id'];
        }
        $query3 = "SELECT * FROM TAG_BAHASA WHERE TAG_NAMA='$judul'";
        $list3 = $conn->query($query3);
        $rowcount3 = mysqli_num_rows($list3);
        if($rowcount3 > 0){
            echo "Data Kembar";
        } else{
            if($id != ""){
                $query = "INSERT INTO tag_bahasa VALUES('',$id,1,'$judul')";
                if($conn->query($query) == true){
                    echo "Berhasil Menambahkan Data";
                }else{
                    echo "Tidak Berhasil Menambahkan Data";
                } 
            } else {
                echo "Tidak Berhasil Menambahkan Data";
            }
        }
    } else {
        echo "Tidak Berhasil Menambahkan Data";
    }
?>