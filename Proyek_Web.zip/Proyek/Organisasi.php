<?php
   require_once("Connection.php");
   require_once("Sumber.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .tabs .tab a{
            color:#000;
            font-size: 16pt;
            font-family: Arial, Helvetica, sans-serif;
    }

    .tabs .tab a:hover {
        background-color:#eee;
        color:#000;
    }
    .tabs .tab a.active {
        background-color:rgba(0,0,0,0.5);
            color:white;
        }
    .tabs .tab a:focus.active {
    background-color:rgba(0,0,0,0.5);
        color:white;
    }
    .tabs .indicator {
        background-color:black;
    }

    .judul{
        font-size: 20pt;
    }
    .subjudul{
        font-size: 16pt;
        font-weight: bold;
    }
    .isi{
        font-size: 15pt;
        font-weight: bold;
    }
    .isi2{
        font-size: 15pt;
        line-height: 1.6;
        text-indent: 25px;
    }
    ul.jenis li {
        font-size: 15pt;
        margin-left: 2vw;
        list-style-type: circle;
    }
    body{
        background-color:rgb(243,243,243)
    }
</style>
<body>
    
        <?php include("Header.php"); ?>
        <?php include("minioverlay.php"); ?>
        <div class="container" style="margin-top:20vh;margin-bottom:40px;">
            <ul class="tabs tabs-fixed-width tab-demo z-depth-1">
                <li class="tab"><a class="active nounderline" id="scr1">BEM</a></li>
                <li class="tab"><a class="nounderline" id="scr2">HIMA</a></li>
                <li class="tab"><a class="nounderline" id="scr3">UKM</a></li>
                <li class="tab"><a class="nounderline" id="scr4">UKK</a></li>
            </ul><br><br>
            <div class="col s12">
            <?php $query = "SELECT * FROM KATEGORI_BAHASA WHERE KATEGORI_BAHASA_ID ='1'";
                $tmp = $conn->query($query);
                foreach ($tmp as $key => $value) { 
                    $tmpid = $value['kategori_id'];
                    $query2 = "SELECT * FROM ORG_BAHASA WHERE KATEGORI_ID = '$tmpid'";
                    $tmp2 = $conn->query($query2);
                    ?>
                    <div class="parallax-container">
                        <div class="parallax"><img src="Image/thumbBEM.jpg"></div>
                    </div>
                    <section>
                        <div class="content" >
                            <div class="judul">Apa itu <?=$value['kategori_nama_pendek']?>???</div><br>
                                <div class="subjudul">
                                    <?=$value['kategori_nama_pendek']?> merupakan singkatan dari <?= $value['kategori_nama']?><br><br>
                                </div>
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <div class="isi2"><?= $val['org_deskripsi']?></div>
                            <?php }}?>
                        </div>
                    </section>
            </div><br><br><br>
            <div class="col s12">
                <?php $query = "SELECT * FROM KATEGORI_BAHASA WHERE KATEGORI_BAHASA_ID ='2'";
                $tmp = $conn->query($query);
                foreach ($tmp as $key => $value) { 
                    $tmpid = $value['kategori_id'];
                    $query2 = "SELECT * FROM ORG_BAHASA WHERE KATEGORI_ID = '$tmpid'";
                    $tmp2 = $conn->query($query2);
                    ?>
                    <div class="parallax-container">
                        <div class="parallax"><img src="Image/hima.jpg"></div>
                    </div>
                    <section>
                        <div class="content" >
                            <div class="judul">Apa itu <?=$value['kategori_nama_pendek']?>???</div><br>
                                <div class="subjudul">
                                    <?=$value['kategori_nama_pendek']?> merupakan singkatan dari <?= $value['kategori_nama']?><br><br>
                                </div>
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <div class="isi2"><?= $val['org_deskripsi']?></div> 
                            <?php break; } ?>
                            <ul class="jenis">
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <li><?= $val['org_nama']?></li>
                            <?php }?>
                            </ul>
                        <?php } ?>
                        </div>
                    </section>
            </div><br><br><br>
            <div class="col s12">
            <?php $query = "SELECT * FROM KATEGORI_BAHASA WHERE KATEGORI_BAHASA_ID ='3'";
                $tmp = $conn->query($query);
                foreach ($tmp as $key => $value) { 
                    $tmpid = $value['kategori_id'];
                    $query2 = "SELECT * FROM ORG_BAHASA WHERE KATEGORI_ID = '$tmpid'";
                    $tmp2 = $conn->query($query2);
                    ?>
                    <div class="parallax-container">
                        <div class="parallax"><img src="Image/ukm.jpg"></div>
                    </div>
                    <section>
                        <div class="content" >
                            <div class="judul">Apa itu <?=$value['kategori_nama_pendek']?>???</div><br>
                                <div class="subjudul">
                                    <?=$value['kategori_nama_pendek']?> merupakan singkatan dari <?= $value['kategori_nama']?><br><br>
                                </div>
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <div class="isi2"><?= $val['org_deskripsi']?></div> 
                            <?php break; } ?>
                            <ul class="jenis">
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <li><?= $val['org_nama']?></li>
                            <?php }?>
                            </ul>
                        <?php } ?>
                        </div>
                    </section>
            </div><br><br><br>
            <div class="col s12">
            <?php $query = "SELECT * FROM KATEGORI_BAHASA WHERE KATEGORI_BAHASA_ID ='4'";
                $tmp = $conn->query($query);
                foreach ($tmp as $key => $value) { 
                    $tmpid = $value['kategori_id'];
                    $query2 = "SELECT * FROM ORG_BAHASA WHERE KATEGORI_ID = '$tmpid'";
                    $tmp2 = $conn->query($query2);
                    ?>
                    <div class="parallax-container">
                        <div class="parallax"><img src="Image/prayer.jpg"></div>
                    </div>
                    <section>
                        <div class="content" >
                            <div class="judul">Apa itu <?=$value['kategori_nama_pendek']?>???</div><br>
                                <div class="subjudul">
                                    <?=$value['kategori_nama_pendek']?> merupakan singkatan dari <?= $value['kategori_nama']?><br><br>
                                </div>
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <div class="isi2"><?= $val['org_deskripsi']?></div> 
                            <?php break; } ?>
                            <ul class="jenis">
                            <?php foreach ($tmp2 as $key => $val) { ?>
                                <li><?= $val['org_nama']?></li>
                            <?php }?>
                            </ul>
                        <?php } ?>
                        </div>
                    </section>
            </div>
        </div>
        <?php include("footer.php");?>
</body>
</html>
<script>
    $(document).ready(function(){
        $('#scr1').click(function () {
            $("html, body").animate({ scrollTop: 500 }, "slow");
        });
        $('#scr2').click(function () {
            $("html, body").animate({ scrollTop: 1500 }, "slow");
        });
        $('#scr3').click(function () {
            $("html, body").animate({ scrollTop: 2500 }, "slow");
        });
        $('#scr4').click(function () {
            $("html, body").animate({ scrollTop: 3500 }, "slow");
        });

        $('.parallax').parallax();
        $('.tabs').tabs();
        
    });
</script>