<?php
  require_once("Connection.php");
  require_once("Sumber.php");

 // session_start();

  $message = "";
  if(isset($_POST["btnLogin"])){
    $tmpuser = $_POST["usernameTxt"];
    $tmppass = $_POST["passTxt"];
    
    $user = strtolower($tmpuser);
    $pass = strtolower($tmppass);
    
    if($user == "admin" && $pass == "admin"){
        $_SESSION['userlogin'] = "Admin";
        $_SESSION['statlogin'] = 1;
        header("Location: admin.php");
    }else{
        $message = "Username atau Password salah. Coba lagi!";
        //echo "<script> alert('Username atau Password salah!'); </script>";
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    body{
        background-image: url("Image/3.jpg");
        background-size: 100% 700px;
        color: white;
    }

    .login{
        margin-top: 100px;
    }

    .login .card{
        background: rgba(0,0,0, 0.6);
    }

    .login h2{
        text-align: center;
    }

    .login label{
        position: absolute;
        top: -10px;
        font-size: 18px;
        color: white;
    }

    .login input{
        font-size: 20px !important;
        color: white;
    }

    .login button:hover{
        padding: 0px 50px;
    }

    p{
        color: red;
        text-align: center;
        font-size: 14pt;
    }
}
</style>
<body>
    <div class="row login">
        <div class="col s12 l4 offset-l4">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>Login Form</h2>
                </div>
                <form action="#" method="post">
                <div class="card-content">
                    <div class="input-field">
                        <i class="material-icons prefix">person</i>
                        <label for="username">Username</label>
                        <input type="text" name="usernameTxt" id="username">
                    </div><br>
                    <div class="input-field">
                    <i class="material-icons prefix">lock</i>
                        <label for="username">Password</label>
                        <input type="password" name="passTxt" id="password">
                    </div><br>
                    <div class="form-field center-align">
                        <p><?=$message?></p>
                        <button class="waves-effect waves-light btn-large" type="submit" value="login" name="btnLogin">Login</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- <form action="#" method="post">
            <div class="container">
                <div class="row" style="width: 40vw;margin: auto;margin-top: 15vh; background: rgba(0,0,0,0.5)">
                    <div class="col s12">
                        <div class="col s12" style="color: white; height: 10vh; font-size: 25pt; text-align: center;padding-top: 2vh;">
                            Form Login
                        </div>
                        <div class="col s12 input-field">
                            <i class="material-icons prefix">person</i>
                            <div style="font-family: Arial; font-size: 16pt; margin-left: 30px; color: white;">Username </div><br>
                            <input type="text" style="font-family: Arial;font-size: 14pt; color: white;" name="usernameTxt" id="UsernameTxt" placeholder="Masukkan Username"><br>
                        </div>
                        <div class="col s12 input-field">
                            <i class="material-icons prefix">lock</i>
                            <div style="font-family: Arial; font-size: 16pt; margin-left: 30px; color: white;">Password </div><br>
                            <input type="password" style="font-family: Arial;font-size: 14pt; color: white;" name="passTxt" id="PassTxt" placeholder="Masukkan Password">
                        </div>
                        <div class="col s12"  style="text-align: center;">
                            <input type="submit" value="Login" name="btnLogin" style=" width: 100%; border: 2px solid lightgrey; border-radius: 5%; font-family: Arial; font-size: 16pt; background: black; color: white;">
                            <button name="btnLogin" id="BtnLogin" style="border-radius: 5%;width: 100%; border: 2px solid lightgrey; background: black; color: white; font-family: Arial; font-size: 16pt;" type="submit">Login</button>
                        </div>
                    </div>
                </div>
            </div>
    </form> -->
</body>
</html>