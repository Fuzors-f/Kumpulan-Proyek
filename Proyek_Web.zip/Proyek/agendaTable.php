<?php
    require_once('Connection.php');
    require_once('Sumber.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    thead tr th{
        padding: 10px;
        font-size: 16pt;
        color: black;
    }
    tbody tr td {
        padding: 15px;
        color: black;
    }
</style>
<body>
    <div class="row tabel">
        <div class="col s12">
            <table class="centered highlight">
                <thead>
                    <tr>
                        <th>ID Agenda</th>
                        <th>Judul Agenda</th>
                        <th>Bahasa</th>
                        <th>Ubah</th>
                        <th>Hapus</tr>
                    </tr>
                    
                </thead>
                <tbody>
                    <?php 
                        $query=mysqli_query($conn,"SELECT * from agenda_bahasa");
                        while($row = mysqli_fetch_assoc($query)){ ?>
                        <tr>
                            <td><?= $row['agenda_bahasa_id']?></td>
                            <td><?= $row['agenda_judul']?></td>
                            <td><?php if($row['bahasa_id'] == 1){ echo "Indonesia";}else{ echo "Inggris";}?></td>
                            <td><form action="Agenda.php" method="post"><button class="waves-effect waves-light btn-small" name="btnEdit" type="submit" value="<?= $row['agenda_bahasa_id']?>"><i class="material-icons">edit</i></button></form></td>
                            <td><form action="Agenda.php" method="post"><button class="waves-effect waves-light btn-small" name="btnDelete" type="submit" value="<?= $row['agenda_bahasa_id']?>"><i class="material-icons">delete</i></button></form></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<script>
    // $(document).ready(function () {
    //     $(".btnEdit").click(function () {
    //         var dataid = $(this).val();
    //         $.ajax({
    //             url: "Agenda.php",
    //             method: 'post',
    //             data: {
    //                 dataid : dataid  
    //             },
    //             success: function(result){
    //                 alert(result);
    //             }
    //         });

    //     });

    //     $(".btn").click(function () {
    //         var dataid = $(this).val();
    //         var konfirm = confirm("Apakah anda yakin untuk menghapus data?");
    //         if (konfirm == true) {
                
    //         }
    //     });
    // });

</script>