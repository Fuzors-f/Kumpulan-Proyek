<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $judul = $_POST["judul"];
    
    if($id != ""){
        $query = "UPDATE TAG_BAHASA SET tag_id='$id', bahasa_id=1, tag_nama='$judul' WHERE tag_bahasa_id='$id'";
        if($conn->query($query) == true){
            echo "Berhasil Mengupdate Data";
            
        }else{
            echo "Tidak Berhasil Mengupdate Data";
        } 
    } else {
        echo "Tidak Berhasil Mengupdate Data";
    }
    
?>