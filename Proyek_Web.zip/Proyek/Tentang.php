<?php require_once("Connection.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Proyek.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="materialize/js/materialize.min.js"></script>
    <style>
        .banner{
            position:absolute;
            z-index:12;
            width:100%;
            left:0;
            height:85vh;
            background-color:rgba(0,0,0,0.8);
            padding-top:26vh;
            margin-bottom: 50vh;
            text-align: center;
            color: white;
        }
        .bgbanner{
            height: 85vh;
            width:100%;
            object-fit: cover;
            object-position: 20% 10px; 
        }
        .text{
          font-size: 40pt; 
        }
        body{
          background-color: rgba(0,0,0,0.8);
        }

        .carousel {
          height: 50vh;
        }
        .card-content{
          height: 250px;
          width: 350px;
        }
        .upright{
            writing-mode: vertical-rl;
          text-orientation: upright;
          font-family: Arial, Helvetica, sans-serif;
            font-weight: bold;
            position : absolute;
            left : 15;
          }
          .jd{
            width: 40%;
            color: white;
            margin-bottom : 20px;
          }
          @media screen and (max-width: 800px) {
            .upright{
              writing-mode: horizontal-tb;
            }
            .jd{
              width: 80%;
              box-shadow: 1px 2px 4px rgba(0, 0, 0, .5);
            }
        }
    </style>
</head>
<body>
    <?php include("Header.php"); ?>
    <style>
      .tabs .tab a{
            color:#000;
            font-size: 16pt;
            font-family: Arial, Helvetica, sans-serif;
        } /*Black color to the text*/

        .tabs .tab a:hover {
            background-color:#eee;
            color:#000;
        } /*Text color on hover*/
        .tabs .tab a.active {
          background-color:rgba(0,0,0,0.5);
              color:#000;
        }
        .tabs .tab a:focus.active {
            background-color:rgba(0,0,0,0.5);
              color:#000;
        }/*Background and text color when a tab is active*/
        .tabs .indicator {
            background-color:#000;
        } /*Color of underline*/
    </style>
    <img src="Image/2.jpg" class="bgbanner" style="position: absolute;left:0;"> 
    <div class="banner"><img src="Image/Logo21.png" alt="" width="200" height="200" style="margin-top: 10vh;">
        <div class="text">Tentang Kami</div>
    </div>
    <br><br><br><br><br><br><br><br><br><br>
    <div class="container" style="margin-top:60vh;margin-bottom:40px;">
      <div class="row">
        <div class="col s12">
          <ul class="tabs"  >
            <li class="tab col s6" ><a class="active nounderline" id="berita" href="#test1-swipe-1">Visi & Misi</a></li>
            <li class="tab col s6" ><a  href="#test2-swipe-2" id="agenda" class="nounderline">Tujuan Pendidikan</a></li>
          </ul>
        </div>
        <div id="test1-swipe-1" class="container " style="margin-top: 40px;padding-top: 20px;height:850px ;">
          <div class="row">
              <div class="col s6" style="text-align:center;">
                  <h1 style="font-size: 25pt"> Visi</h1>
                  <hr>
                  <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;font-size: 14pt">
                  Pada Tahun 2022, STTS menjadi perguruan tinggi unggulan bidang sains, teknologi, dan desain
                  yang mampu bersaing di tingkat Asia Tenggara, dengan mengedepankan kualitas, inovasi, dan nilai-nilai
                  keindonesiaan
                  </p>
              </div>
              <div class="col s6" style="text-align:center;">
                  <h1 style="font-size: 25pt"> Misi</h1>
                  <hr>
                  <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;"><span style="font-size: 15pt">1.</span>
                          Memberikan materi pendidikan dan pengajaran terbaik di bidang sains, teknologi, dan desain, 
                          dalam sistem tata kelola organisasi yang efisien disesuaikan dengan situasi dan 
                          kondisi kebutuhan  dan perkembangan sosial, ekonomi,  dan budaya masyarakat Indonesia.
                  </p>
                  <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;"><span style="font-size: 15pt">2.</span>
                      Bekerja sama dengan berbagai perguruan tinggi dan industri di Indonesia,  melakukan penelitian 
                      terapan bidang sains, teknologi, dan desain, disesuaikan dengan situasi, kondisi,  kebutuhan, dan perkembangan masyarakat Indonesia. 
                  </p>
                  <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;"><span style="font-size: 15pt">3.</span>
                      Menyediakan berbagai solusi inovatif dan unggul berbasis sains, teknologi, dan desain bagi berbagai masalah sosial, ekonomi,  dan budaya, 
                      khususnya dalam  menghadapi pasar masyarakat ekonomi ASEAN dan Trans Pacific Partnership (TPP).
                  </p>
              </div>
          </div>
        </div>
        <div id="test2-swipe-2" class="container"style="margin-top: 40px;height:850px;" >
          <div style="font-size: 14pt; margin:auto;"><br>
              1. Tersusunnya kurikulum pendidikan dan pengajaran bidang sains, teknologi, dan desain   yang makin spesifik, unggul, dan sejalan dengan perkembangan bidang sains, teknologi, dan desain terkini di Indonesia. <br><br>
              2. Tersedianya sumber daya manusia dengan kompetensi keilmuan yang makin spesifik dan fasilitas pendidikan/ pengajaran bidang sains, teknologi, dan desain yang      handal dan sesuai dengan perkembangan bidang sains, teknologi, dan desain terkini di Indonesia. <br><br>
              3. Lulusnya para sarjana bidang sains, teknologi, dan desain dengan kemampuan bidang sains, teknologi, dan desain yang berkualitas dan berkompetensi sejalan dengan        perkembangan bidang sains, teknologi, dan desain, dan mampu bekerja secara mandiri/ di perusahaan nasional ternama pada bidang yang relevan di Indonesia. <br><br>
              4. Meningkatnya penelitian terapan bidang sains, teknologi, dan desain yang makin spesifik sesuai dengan situasi, kondisi, dan kebutuhan masyarakat Indonesia yang  berorientasikan pada peningkatan daya saing ekonomi. <br><br>
              5. Meningkatnya kerjasama penelitian terapan bidang sains, teknologi, dan desain yang makin spesifik dengan perguruan tinggi yang ada di seluruh wilayah Indonesia. <br><br>
              6. Meningkatnya kerjasama penelitian terapan bidang sains, teknologi, dan desain yang makin spesifik dengan industri yang ada di seluruh wilayah Indonesia. <br><br>
              7. Meningkatnya kegiatan pengabdian masyarakat dan penyelesaian masalah masyarakat di bidang sains, teknologi, dan desain yang ada di seluruh wilayah Indonesia. <br><br>
              8. Meningkatnya jumlah civitas akademika STTS yang terlibat dalam kegiatan pengabdian masyarakat dan penyelesaian masalah masyarakat di bidang sains,  teknologi, dan desain yang makin spesifik di seluruh wilayah Indonesia. <br><br>
              9. Berkembangnya citra STTS sebagai perguruan tinggi bidang bidang sains, teknologi, dan desain yang berkualitas di masyarakat di seluruh wilayah Indonesia. <br>
          </div>
        </div>
      </div>
    </div>


     <div class="container">
     <h1 class="upright"> OUR HISTORY </h1>
      <div class="carousel" >
          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px; width: 280px;"></div>
               <b>1979</b><br>
               STTS pada mulanya dikenal dengan Institut Teknisi Elektro Surabaya (ITES) yang didirikan pada 1 Maret 1979. ITES berlokasi di jalan Bali No.17 Surabaya dan dibawah naungan Yayasan Perguruan Tinggi Teknik Nusantara. Penyelenggaraan perguruan tinggi ini didasarkan atas kesadaran untuk ikut berperan serta dalam memenuhi kebutuhan pendidikan tinggi khususnya di bidang teknik elektro.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px; width: 280px;"></div>
               <b>1980</b><br>
               Dengan jumlah mahasiswa yang semakin banyak, kampus ITES pindah ke jalan Gubeng Pojok no. 15 Surabaya.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px; width: 280px;"></div>
               <b>1982</b><br>
               STIES berubah nama menjadi Sekolah Tinggi Elektroteknik Surabaya (STIELS) dan memperoleh status Terdaftar hingga program sarjana lengkap S1 (insinyur). Untuk memenuhi kebutuhan masyarakat akan tenaga ahli bidang komputer dengan masa pendidikan yang cepat, tahun itu juga STIELS menyelenggarakan program Diploma 3 jurusan Manajemen Informatika dan Teknik Komputer.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px; width: 280px;"></div>
               <b>1983</b><br>
               Dengan pengesahan dari Kopertis Wilayah VII, STIELS menyelenggarakan program sarjana penuh melalui SK Menteri Pendidikan dan Kebudayaan RI No. 261/O/1983. Pada Desember 1983, STIELS mulai mengikuti ujian sarjana muda dan pada tahun berikutnya mulai mengikuti ujian sarjana negara. STIELS merupakan perguruan tinggi swasta pertama di luar Jakarta dan Bandung yang mengikuti ujian sarjana negara.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>1985</b><br>
               STIELS berganti nama menjadi Sekolah Tinggi Teknik Surabaya (STTS) dan membuka jurusan baru, yaitu Strata-1 Teknik Informatika dan Komputer. Sejak itu pula kegiatan belajar mengajar secara bertahap dipindahkan ke kampus baru di jalan Ngagel Jaya Tengah No. 73-77 yang dilengkapi dengan gedung laboratorium.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>1988</b><br>
               Tim Akreditasi Direktorat Jendral Pendidikan Tinggi Republik Indonesia memutuskan kenaikan status TERDAFTAR menjadi DIAKUI untuk semua program studi yang ada di STTS, yaitu : • Strata-1 Teknik Elektro. • Strata-1 Teknik Informatika dan Komputer. • Diploma-3 Manajemen Informatika dan Teknik Komputer.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>1992</b><br>
               STTS membuka jurusan Strata-1 Teknik dan Manajemen Industri, yang membekali mahasiswa dengan sejumlah teknik dan ilmu manajemen  di bidang industri. Selain itu program ini juga menekankan penggunaan komputer sebagai unsur.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>1993</b><br>
               Pemerintah melalui Direktorat Jendral Pendidikan Tinggi Republik Indonesia memutuskan kenaikan status dari DIAKUI menjadi DISAMAKAN untuk 3 (tiga) program studi, yaitu : • Strata-1 Teknik Elektro. • Strata-1 Teknik Informatika dan Komputer. • Diploma-3 Manajemen Informatika dan Teknik Komputer.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>1997</b><br>
               Pertama kali Depdikbud menerapkan akreditasi, STTS ditetapkan sebagai Perguruan Tinggi Terakreditasi (yang pertama di Indonesia Timur diantara perguruan tinggi swasta jurusan sejenis).
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2000</b><br>
               mation Technology (BIT) dan program studi lanjut untuk jenjang master di SUT.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2003</b><br>
               Untuk menghasilkan sumber daya manusia di bidang teknologi informasi, STTS menyelenggarakan Program Pascasarjana. Program Pascasarjana program studi Teknologi Informasi STTS merupakan program pascasarjana perguruan tinggi swasta pertama di Jatim yang berbasiskan teknologi informasi.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2006</b><br>
               STTS menyelenggarakan program Strata-1 Sistem Informasi Bisnis, dengan tujuan menghasilkan sarjana dengan kemampuan yang merupakan perpaduan antara ilmu informatika dan manajemen.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2008</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2009</b><br>
               Tahun 2009, STTS membuka program Studi S1 Teknik Informatika untuk tenaga professional di bidang IT, dimana perkuliahan diselenggrakan pada sore hingga malam hari. Kegiatan ini tetap diselenggrakan dengan kualitas sama dengan program S1 Teknik Informatika yang diselenggrakan pada siang hari.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2011</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2012</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2014</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2015</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2016</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="card" style="width: 330px; height: auto;">
              <div class="card-content">
               <div style="background-color: gray; height: 10px;width: 280px;"></div>
               <b>2017</b><br>
               STTS merupakan perguruan tinggi berbasis teknologi informasi yang tentunya mampu memberikan kontribusi di bidang desain. Selaras dengan kebutuhan dan permintaan tenaga desain yang semakin banyak masuk ke STTS pada tahun 2008, STTS membuka jurusan Desain Komunikasi Visual.
              </div>
            </div>
          </div>
        </div>
     </div> 
      
      <div style="width:100%;margin-top:30px;background-color: rgba(0,0,0,0.2);padding-top: 40px;">
          <div class="container" >
            <div style="height:80px;background-color: black;margin-top: -60px; padding-top: 5px; " class="jd"> <h1 class="center-align"> OuR Facility </h1></div>
              <div class='row'>
                <div class="col s4">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/non.jpg" alt="" height="250" width="250" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <hr style="border:2px solid white;">
                  <div style="font-style:20pt;margin-top:20px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    Laboraturium
                  </div>
                </div>

                <div class="col s4">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/non.jpg" alt="" height="250" width="250" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <hr style="border:2px solid white;">
                  <div style="font-style:20pt;margin-top:20px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    Libarary
                  </div>
                </div>

                <div class="col s4">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/non.jpg" alt="" height="250" width="250" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <hr style="border:2px solid white;">
                  <div style="font-style:20pt;margin-top:20px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    E-lib
                  </div>
                </div>

              </div>
              <div class="row">
              
                <div class="col s4">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/non.jpg" alt="" height="250" width="250" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <hr style="border:2px solid white;">
                  <div style="font-style:20pt;margin-top:20px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    Honestl Cafe
                  </div>
                </div>

                <div class="col s4">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/non.jpg" alt="" height="250" width="250" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <hr style="border:2px solid white;">
                  <div style="font-style:20pt;margin-top:20px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    Auditorium
                  </div>
                </div>

                <div class="col s4">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/non.jpg" alt="" height="250" width="250" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <hr style="border:2px solid white;">
                  <div style="font-style:20pt;margin-top:20px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    Rooftop
                  </div>
                </div>

              </div>
              
          </div>
      </div>
      <div style="width:100%;background-color: rgba(0,0,0,0.9);padding-top: 40px;">
          <div class="container"style="color:white;" >
              <div style="height:80px;background-color: black;margin-top: -60px; padding-top: 5px; " class="jd"> <h1 class="center-align"> OuR Rector </h1></div>
              <div class="col s12">
                  <div class="center-align" style="margin-bottom: 50px;">  <img src="Image/profile.jpg" alt="" height="150" width="150" class="circle responsive-img"> <!-- notice the "circle" class --></div>
                  <h1 class="center-align" style="font-size:25pt">Nama</h1>
                  <div style="font-style:20pt;margin-top:14px;font-style:italic; font-weight:bold;margin-bottom: 100px;" class="center-align">
                    "bla bla bla "
                  </div>
                </div>
          </div>
      </div>
    <?php include("footer.php"); ?>
</body>
</html>
<script>
  $(document).ready(function () {
     
    $('.carousel').carousel();
    $('.tabs').tabs();
     $('ul.tabs').tabs({
       swipeable: true,
       responsiveThreshold: Infinity
     });
    
   
    
    // setInterval(function () {
    //   $('.carousel').carousel('next');
    // },3000);

    
  
  });
  

</script>

