<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $judul = $_POST["judul"];
    $desc = $_POST["desc"];
    $tajuk = $_POST["tajuk"];
    $hal = $_POST["hal"];
    $stgl = $_POST["stgl"];
    $tag = $_POST["tag"];
    $src = $_POST["src"];
    $tgl = date("Y-m-d H:i:s");

    $quwery = "SELECT * from media_BAHASA WHERE media_bahasa_id = $id";
    $list = $conn->query($quwery);
    $mediab = '';
    foreach ($list as $key => $value) {
        $mediab = $value['media_id'];
    }
    $query2 = "UPDATE media SET media_foto='$src', media_tanggal='$tgl', media_sumber_tajuk='$tajuk', media_sumber_hal='$hal', media_sumber_tgl='$stgl' WHERE agenda_id='$mediab'";
    if($id != ""){
        $querys = "UPDATE KONTEN_TAG SET TAG_ID= $tag WHERE KONTEN_PARENT= $mediab and KONTEN_ID =3";
        $query = "UPDATE media_BAHASA SET media_id='$mediab', media_judul='$judul', media_deskripsi='$desc' WHERE media_bahasa_id='$id'";
        if($conn->query($query) == true && $conn->query($querys) == true){
            echo "Berhasil Mengupdate Data";
        }else{
            echo "Tidak Berhasil Mengupdate Data";
        } 
    } else {
        echo "Tidak Berhasil Mengupdate Data";
    }  
?>