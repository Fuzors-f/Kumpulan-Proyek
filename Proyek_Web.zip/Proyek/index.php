<?php
  require_once("Connection.php");
  require_once("Sumber.php");
  //$id =1;
  $idtest = [];
  $namatest =[];
  $testprofil = [];
  $isitesti = [];
  $query = "select * from testimoni";
  $rs = mysqli_query($conn,$query);
  foreach($rs as $key=>$data){
      $idtest[Count($idtest)] = $data['testimoni_id'];
      $namatest[Count($namatest)] = $data['testimoni_nama'];
  }
  for($i=0; $i<Count($idtest);$i++){
    $qw = "select * from testimoni_bahasa where testimoni_id = $idtest[$i]";
    $rs  = mysqli_query($conn,$qw);
    foreach($rs as $key=>$data){
      $isitesti[Count($isitesti)] = $data['testimoni_text'];
      $testprofil[count($testprofil)] = $data['testimoni_profil'];
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
</head>
<style>
   
    .card-content{
        height:160px; 
        overflow: hidden;
    }
    .card-image{
        height:180px;
        overflow: hidden;
    }
    .overlay p{
      font-size: 12pt;
    }

    @media screen and (max-width: 800px) {
      .overlay #maintitle{
        margin-top: -70px;
      }
      .overlay p{
        margin-top: -2px;
      }
      .overlay .btns{
        margin-top: -40px;
      }
     
  }
  .upright{
    writing-mode: vertical-rl;
   text-orientation: upright;
   font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
  }
  .tabs .tab a{
            color:#000;
            font-size: 16pt;
            font-family: Arial, Helvetica, sans-serif;
   } /*Black color to the text*/

  .tabs .tab a:hover {
      background-color:#eee;
      color:#000;
  } /*Text color on hover*/
  .tabs .tab a.active {
    background-color:rgba(0,0,0,0.5);
        color:#000;
       }
    .tabs .tab a:focus.active {
      background-color:rgba(0,0,0,0.5);
        color:#000;
  }/*Background and text color when a tab is active*/
  .tabs .indicator {
      background-color:#000;
  } /*Color of underline*/
  .collapsible-header, .collapsible-body, .collapsible, ul.collapsible>li 
    {
      margin: 0!important;;
      padding: 0!important;
      border: 0!important;
      box-shadow: none!important;
      background: #fff;
    }

    .bx:hover{
      cursor:pointer;
    }

</style>
<body>   
  <?php include("Header.php"); ?>
  <div class="overlay" style="height: 100vh;padding-top:40vh;background-color:rgba(0,0,0,0.7);"><div id="maintitle" style="font-size:22pt;">INSTITUT SAINS DAN TEKNOLOGI TERPADU SURABAYA</div>
          <p>iSTTS pada mulanya dikenal dengan Institut Teknisi 
            Elektro Surabaya (ITES) yang didirikan pada tanggal 1 Maret 1979. </p><p>ITES berlokasi di jalan Bali no. 17 Surabaya dan dibawah naungan Yayasan Perguruan Tinggi Teknik Nusantara.
          </p><br><br>
          <div class="btns" id="lengkap">Selengkapnya</div>
    </div>
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" style="height: 100vh;">
        <div class="carousel-inner">
            <div class="item active">
              <img src="Image/1.jpg" alt="...">
              <div class="carousel-caption" ></div>
            </div>
            <div class="item">
              <img src="Image/2.jpg" alt="...">
              <div class="carousel-caption"></div>
            </div>
        </div>
    </div>

    <div style="width:100%; background-color:rgba(0,0,0,1);color:white;">      
              <div class="container bx" style="padding:100px;" id="1">
                  <div class="row">
                    <div class="animation" style="font-size:30pt; font-weight:bold;text-align:center;">MENGAPA PERLU MEMILIH ISTTS</div> 
                    <hr style="text-align:center; border:2px solid white; width:40%;"><br>
                  </div>
                  <div class="row" style="text-align:center;margin-top:-40px;">
                       <span style="font-size:15pt;font-weight:bold;" class="rowke"> TESTIMONY</span>
                  </div>
             </div>     
    </div>

      
        <ul class="collapsible" style='border:1px solid black;'>
          <li>
          <div class="collapsible-header">
          <div style="width:100%; background-color:rgba(0,0,0,1);color:white;">
             
                <div class="container" style="padding:100px;">
                  <div class="row">
                    <div class="animation" style="font-size:30pt; font-weight:bold;text-align:center;">CHECK OUR CONTENT RIGHT HERE </div> 
                    <hr style="text-align:center; border:2px solid white; width:40%;"><br>
                  </div>
                  <div class="row" style="text-align:center;margin-top:-40px;">
                       <span style="font-size:15pt;font-weight:bold;" class="rowke"> AGENDA•BERITA•MEDIA•TAG</span>
                  </div>
             </div>
             
            </div>
          </div>

          <div class="collapsible-body">
             <div style="width:100%; height: auto;">
                <div class="container" style="margin-top:50px;">
                  <div class="row">
                      <div class="col s12">
                        <ul class="tabs" style="margin-left: 10vw;">
                          <li class="tab col s3" ><a class="active nounderline" id="berita" href="#test1-swipe-1">Berita</a></li>
                          <li class="tab col s3" ><a  href="#test2-swipe-2" id="agenda" class="nounderline">Agenda</a></li>
                          <li class="tab col s3" ><a href="#test3-swipe-3" id="media" class="nounderline">Media</a></li>
                        </ul>
                      </div>
                      <div id="test1-swipe-1" class="col s12" style="margin-top: 40px;padding-top: 20px;">
                        <div class="berita" style="margin-top:40px;"></div>
                      </div>
                      <div id="test2-swipe-2" class="col s12"style="margin-top: 40px;">
                        <div class="agenda" style="margin-top:40px;"></div>
                      </div>
                      <div id="test3-swipe-3" class="col s12"style="margin-top: 40px;">
                        <div class="media" style="margin-top:40px;"></div>
                      </div>
                  </div>
                </div>
              </div>
              
              <div class="container" style="margin-top:25px;margin-bottom: 100px;">
                <p class="upright" id="upper">DISCOVER</p>
                <p><h1 >| YOUR FUTURE START HERE.</h1>
                <div class="tags"></div>
              </div>
          </div>
          </li>
        </ul>
      
        <div style="width:100%; background-color:rgba(0,0,0,1);color:white;">
             
             <div class="container bx" style="padding:100px;" id="2">
               <div class="row">
                 <div class="animation" style="font-size:30pt; font-weight:bold;text-align:center;">NOT YET SATIFIED WITH OUR CONTENT??</div> 
                 <hr style="text-align:center; border:2px solid white; width:40%;"><br>
               </div>
               <div class="row" style="text-align:center;margin-top:-40px;">
                    <span style="font-size:15pt;font-weight:bold;" class="rowke"> CHECK OUR WEBSITE HERE</span>
               </div>
          </div>
          
         </div>

    <?php include("footer.php"); ?>
</body>
</html>
<script>
    function loadberita(){
      $(".berita").load("Controlerberita.php");
    }

    function loadmedia(){
      $(".media").load("Controlermedia.php");
    }

    function loadagenda(){
      $(".agenda").load("Controleragenda.php");
    }


    $(document).ready(function(){
      loadberita(); 
      $(".tags").load("Menutag.php");
      $('.collapsible').collapsible();
        $('.animation').textillate({
            loop: true,
            autoStart: true,
            in: {
                effect: 'fadeInDown',
                // set the delay factor applied to each consecutive character
                delayScale: 1.5,
                // set the delay between each character
                delay: 100,
                // randomize the character sequence
                shuffle: true
            },
            out: {
                effect: 'fadeOutDown',
                delayScale: 1.5,
                delay: 100,
                shuffle: true
            }
        });
      var bol = false;
        
        // $(window).scroll(function() {
        //   var hT = $('#upper').offset().top,
        //       hH = $('#upper').outerHeight(),
        //       wH = $(window).height(),
        //       wS = $(this).scrollTop();
        //   if (wS > (hT+hH-wH)){
        //       console.log("masuk JANCOK");
        //         $('#upper').textillate({

        //           minDisplayTime: 5000
        //         });
              
        //   }
        // });
        // $(window).scroll(function () {
         
        //     if($(window).scrollTop()>=1500){
        //       // alert("Kelebihan WOI!!");
        //        bol = true;
        //       if(bol){
        //         alert(bol);
                
        //       }
        //     }
        // });

      
          $("#maintitle").animate({
            lineHeight: "+=1em",letterSpacing: "+=10px"
            },1000);
        $("#lengkap").click(function () {
          //$("html, body").animate({ scrollTop: 500 }, "slow");
          window.location.href = 'Tentang.php';
        });
        $('.tabs').tabs();

        $("#berita").click(function () {
          $(".media").html("");
          $(".agenda").html("");
          loadberita();
        });

        $("#1").click(function(){
          window.location.href = 'Testimoni.php?urlpage=Testimoni';
        });

        $("#2").click(function(){
          window.location.href = 'https://istts.ac.id/';
        });
        $("#media").click(function () {
          $(".berita").html("");
          $(".agenda").html("");
          loadmedia();
        });
        
        $("#agenda").click(function () {
          $(".berita").html("");
          $(".media").html("");
          loadagenda();
        });
    });

</script>