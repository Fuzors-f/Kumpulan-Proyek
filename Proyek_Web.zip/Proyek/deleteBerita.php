<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $quwery = "SELECT * from BERITA_BAHASA WHERE berita_bahasa_id = $id";
   
    $list = $conn->query($quwery);
    $beritab = '';
    foreach ($list as $key => $value) {
        $beritab = $value['berita_id'];
    }
    
    $qwery2 = "SELECT * FROM KONTEN_TAG WHERE KONTEN_PARENT = $beritab";
    $list3 = $conn->query($qwery2);
    $rowcount2 = mysqli_num_rows($list3);
    if($rowcount2 > 0){
        $query2 = "DELETE FROM KONTEN_TAG WHERE KONTEN_PARENT = $beritab";
        if($conn->query($query2) == true){
            echo "Berhasil Menghapus Data di Konten_tag";
        }else{
            echo "Tidak Berhasil Menghapus Data di Konten_tag";
        }
    }

    $qwery = "SELECT * FROM BERITA_BAHASA WHERE BERITA_ID = $beritab";
    $list2 = $conn->query($qwery);
    $rowcount = mysqli_num_rows($list2);
    if($rowcount > 1){
        $query = "DELETE FROM BERITA_BAHASA WHERE BERITA_BAHASA_ID='$id'";
        
        if($conn->query($query) == true){
            echo "Berhasil Menghapus Data (Translate)";
        }else{
            echo "Tidak Berhasil Menghapus Data (Translate)";
        }
    }else{
        $query = "DELETE FROM BERITA_BAHASA WHERE BERITA_ID='$beritab'";
        $query2 = "DELETE FROM BERITA WHERE BERITA_ID='$beritab'"; //351

        if($conn->query($query) == true && $conn->query($query2)== true){
            echo "Berhasil Menghapus Data Utama";
        }else{
            echo "Tidak Berhasil Menghapus Data Utama";
        } 
    }
?>