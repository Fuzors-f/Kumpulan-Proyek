<?php
   // session_start();
   require_once("Sumber.php");
   $_SESSION['bahasa'] = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    nav{
        position: fixed;
        background: rgba(255,255,255,0.9);
        padding: 10px 20px;
        height: 18vh;
        border-radius: 30px;
        z-index: 30;
        width: 90vw;
        margin-left: 4vw;
        
    }

    .background{
        background-image: url("Image/3.jpg"); 
        background-size: cover;
        height: 50vh;
        width:100%;
        
    }

    .box{
        margin-top: 20px;
        height: 1000px;
    }

    nav li a{
        color: black;
        font-size: 18pt;
        padding: 10px 20px;
    }
    nav li a:hover{
        background: grey;
        color: white;
        text-decoration: none;
        border-radius: 25px;
    }

    .navigator{
        position: absolute;
        width: 100%;
        height: 12vh;
        text-align: center;
        z-index: 25;
        background-color: rgba(0,0,0,0.8);
        padding-left: 2.5vw;
        color: white;
        top:0vh;
        padding-top:7px;
        font-size: 10pt;
        display:inline-block;
    }

    .atas li { 
        display: inline;
        color: white;
        font-size: 12pt;
    }

    i{
        position: absolute;
    }

    #keatas img{
        position: fixed;
        top: 85vh;
        right: 2vw;
        cursor: pointer;
        z-index: 200;
    }

    .woy:hover{
        cursor:pointer;
        color: white;
    }

    .navigator ul.atas .status li {
        margin-top: 2vh;
        align: center;
        margin-left: 12vw;
    }
 
    .navigator ul.atas .status li i{
        margin-left: -25px;
    }

    .navigator ul.atas .bahasa{
        position: absolute;
        right: 1vw;
    }

    .navigator ul.atas .bahasa li{
        margin-left: 0vw;
    }

    .delimiter{
        font-size: 20pt;
        margin-left: -2px;
        color: lightblue;
    }

    .delimiter2{
        display: none;
    }

    .aktif{
        color: lightblue;
    }
    @media only screen and (max-width: 1000px){
        .navigator ul.atas .status li {
            margin-top: 0.5vh;
            align: center;
            margin-left: 5vw;
        }
    
        .navigator ul.atas .status li i{
            margin-left: -25px;
        }

        .navigator ul.atas .bahasa{
            position: absolute;
            top: 0.5vh;
            right: -3vw;
        }

        .navigator ul.atas .bahasa li{
            font-size: 12pt;
            margin-left: -0.1vw;
        }

        .delimiter{
            display: none;
        }

        .delimiter2{
            display: block;
            font-size: 20pt;
            margin-top: -4.5vh;
            color: lightblue;
        }
        .status{
            font-size:8pt;
        }
        
    }
</style>
<body>
<div class="navigator">
    <ul class="atas">
        <div class="status">
            <li class="nounderline left"><i class="small material-icons">call</i>+62 31 502 7920</li>
            <li class="nounderline left"><i class="small material-icons">mail_outline</i>web_admin@istts.ac.id</li>
            <li class="nounderline left"><i class="small material-icons">location_on</i>Jalan Ngagel Jaya Tengah 73 - 77, Surabaya, Indonesia</li>
        </div>
        <div class="bahasa">
            <li><a onclick="eng()" class="woy nounderline" id="en">EN</a></li>
            <li><span class="delimiter">|</span></li> 
            <li><span class="delimiter2">__</span></li> 
            <li><a onclick="ind()" class="aktif woy nounderline" id="ind">IND</a></li>
        </div>
    </ul>
</div>
    <nav>
        <div class="nav-wrapper" style="padding-top:10px;">
            <a href="index.php" class="brand-logo" style="margin-right: 500px;margin-left: 5px;"><img src="Image/logo.png" width="250px" height="80px"></a>
            <a href="#" class="sidenav-trigger" data-target="mobile-links">
                <i class="material-icons" style="color: black;">menu</i>
            </a>
            <ul class="right hide-on-med-and-down" style="padding-top:2px;">
                <li><a href="Dosen.php?urlpage=Dosen" class="nounderline">DOSEN</a></li>
                <li><a href="Jurusan.php?urlpage=Jurusan" class="nounderline">JURUSAN</a></li>
                <li><a href="https://pmb.stts.edu/manajemen/index.php" class="nounderline">PENDAFTARAN</a></li>
                <li><a href="Organisasi.php?urlpage=Aktivitas Mahasiswa"  class="nounderline">AKTIVITAS MAHASISWA</a></li>
            </ul>  
        </div>
    </nav>
    <div id="keatas"><img src="Image/totop.gif" alt="" width="50px" height="50px"></div>
    <ul class="sidenav" id="mobile-links">
        <li><a href="Dosen.php?urlpage=Dosen" class="nounderline">DOSEN</a></li>
        <li><a href="Jurusan.php?urlpage=Jurusan" class="nounderline">JURUSAN</a></li>
        <li><a href="https://pmb.stts.edu/manajemen/index.php" class="nounderline">PENDAFTARAN</a></li>
        <li><a href="Organisasi.php?urlpage=Aktivitas Mahasiswa"  class="nounderline">AKTIVITAS MAHASISWA</a></li>
    </ul>    
</body>
</html>
<script>
    $(document).ready(function () {
        $("nav").animate({top: '10vh'},100);
        $(window).scroll(function () {
            if($(window).scrollTop()>150){
                $("nav").animate({top: '0'},100);
                $("#keatas").fadeIn();
            }else{
                $("nav").animate({top: '10vh'},100);
                $("#keatas").fadeOut();
            }
        });
        $(".sidenav").sidenav();
        $("#keatas").click(function () {
          $("html, body").animate({ scrollTop: 0 }, "slow");
        });
        
        $('.dropdown-trigger').dropdown();
       
    });
    function ind(){
        $("#en").removeClass("aktif");
        $("#ind").addClass("aktif");
        $.post("bahasa.php",
            {
                "action":"1",
            },function(data){
                M.toast({html: 'Bahasa Indonesia'});
                $.post("gantiEnglishBerita.php",
                {
                    id : <?php echo $id; ?>
                },function(data){
                    $(".isiBerita").html(data);
                });
                $.post("gantiEnglishMedia.php",
                {
                    id : <?php echo $id; ?>
                },function(data){
                    $(".isiMedia").html(data);
                });
            });

     
      
    }
    function eng(){
        $("#ind").removeClass("aktif");
        $("#en").addClass("aktif");
        $.post("bahasa.php",
            {
                "action":"2",
            },function(data){
                M.toast({html: 'English language'});
                $.post("gantiEnglishBerita.php",
                {
                    id : <?php echo $id; ?>
                },function(data){
                    $(".isiBerita").html(data);
                });
                $.post("gantiEnglishMedia.php",
                {
                    id : <?php echo $id; ?>
                },function(data){
                    $(".isiMedia").html(data);
                });
            });

            
    }
</script>