<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="Proyek.css">
    <script src="jquery.min.js"></script>
</head>
<body>
   <?php include("Header.php"); ?>
   <?php include("minioverlay.php"); ?>
    <div class="container" style="padding:20px;margin-top:20vh;">
        <div style="margin-left:35%"><h1>Tujuan Pendidikan</h1></div>
    
    <div style="font-size:1.5vw; border-radius:20px; border: 2px solid black;padding:20px; margin:auto;"><br>
            1. Tersusunnya kurikulum pendidikan dan pengajaran bidang sains, teknologi, dan desain   yang makin spesifik, unggul, dan sejalan dengan perkembangan bidang sains, teknologi, dan desain terkini di Indonesia. <br><br>
            2. Tersedianya sumber daya manusia dengan kompetensi keilmuan yang makin spesifik dan fasilitas pendidikan/ pengajaran bidang sains, teknologi, dan desain yang      handal dan sesuai dengan perkembangan bidang sains, teknologi, dan desain terkini di Indonesia. <br><br>
            3. Lulusnya para sarjana bidang sains, teknologi, dan desain dengan kemampuan bidang sains, teknologi, dan desain yang berkualitas dan berkompetensi sejalan dengan        perkembangan bidang sains, teknologi, dan desain, dan mampu bekerja secara mandiri/ di perusahaan nasional ternama pada bidang yang relevan di Indonesia. <br><br>
            4. Meningkatnya penelitian terapan bidang sains, teknologi, dan desain yang makin spesifik sesuai dengan situasi, kondisi, dan kebutuhan masyarakat Indonesia yang  berorientasikan pada peningkatan daya saing ekonomi. <br><br>
            5. Meningkatnya kerjasama penelitian terapan bidang sains, teknologi, dan desain yang makin spesifik dengan perguruan tinggi yang ada di seluruh wilayah Indonesia. <br><br>
            6. Meningkatnya kerjasama penelitian terapan bidang sains, teknologi, dan desain yang makin spesifik dengan industri yang ada di seluruh wilayah Indonesia. <br><br>
            7. Meningkatnya kegiatan pengabdian masyarakat dan penyelesaian masalah masyarakat di bidang sains, teknologi, dan desain yang ada di seluruh wilayah Indonesia. <br><br>
            8. Meningkatnya jumlah civitas akademika STTS yang terlibat dalam kegiatan pengabdian masyarakat dan penyelesaian masalah masyarakat di bidang sains,  teknologi, dan desain yang makin spesifik di seluruh wilayah Indonesia. <br><br>
            9. Berkembangnya citra STTS sebagai perguruan tinggi bidang bidang sains, teknologi, dan desain yang berkualitas di masyarakat di seluruh wilayah Indonesia. <br>
        </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>