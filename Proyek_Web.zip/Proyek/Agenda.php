<?php
    require_once('Connection.php');
    require_once('Sumber.php');
    $agendaid = [];
    $judulagenda =[];
    $querys = "select * from agenda_bahasa where bahasa_id = 1";
    $rs = mysqli_query($conn, $querys);
    foreach($rs as $key=>$data){
        $agendaid[Count($agendaid)] = $data['agenda_id'];
        $judulagenda[Count($judulagenda)] = $data['agenda_judul'];
    }
    $action = 0;
    if(isset($_REQUEST['btnEdit'])){
        $dataid = $_POST['btnEdit'];
        $action = 1;
        $query2 = "SELECT * FROM AGENDA_BAHASA WHERE AGENDA_BAHASA_ID='$dataid'";
        $idx ='';
        $list2 = $conn->query($query2);
        foreach($list2 as $key=>$data){
            $idx = $data['agenda_id'];
        }
        $query = "SELECT * FROM AGENDA WHERE AGENDA_ID=$idx";
        $list = $conn->query($query);
        
    }

    if(isset($_REQUEST['btnDelete'])){
        $dataid = $_POST['btnDelete'];
        $action = 2;

        $query2 = "SELECT * FROM AGENDA_BAHASA WHERE AGENDA_BAHASA_ID='$dataid'"; 
        $list2 = $conn->query($query2);
    }

    if(isset($_REQUEST['up'])){
        $target_dir = "Image/"; //<- ini folder tujuannya
        $target_file = $target_dir. basename($_FILES["gambar"]["name"]); //murni mendapatkan namanya saja tanpa path nya 
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if($file_type !="jpg" && $file_type !="png"){
            echo "tipe file hanya jpg dan png saja";
        } else if($_FILES["gambar"]["size"] > 500000){
            echo "file size terlalu besar";
        } else if(file_exists($target_file)){
            echo "file sudah ada";
        }
        else{
            if(move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)){
                echo "file ".basename($_FILES["gambar"]["name"])." terupload";
            }
        }     
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .agenda label{
        position: absolute;
        top: -10px;
        font-size: 20px;
    }

    .agenda button:hover{
        padding: 0px 50px;
    }

    .judul{
        text-align: left;
        font-size: 18px;
        color: grey;
        font-weight: bold;
    }
    .preview{
        width: 100px;
        height: 100px;
        border: 1px solid black;
        margin: 0 auto;
        background: white;
    }

    .preview img{
        display: none;
    }

</style>
<body>
<?php if($action == 0){ ?>
    <div class="row agenda">
        <div class="col s12">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>CRUD Agenda --- CREATE</h2>
                </div>
                <div class="card-content">
                    <div class="input-field">
                    <div class="judul">Judul Agenda <i class="material-icons left" style="color: black;">title</i></div>
                        <input type="text" name="judulTxt" id="JudulTxt">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Lokasi<i class="material-icons left" style="color: black;">location_on</i></div>
                        <input type="text" name="lokasi" id="Lokasi">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Contact Person Email<i class="material-icons left" style="color: black;">email</i></div>
                        <input type="text" name="cpemail" id="CpEmail">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Contact Person Telp<i class="material-icons left" style="color: black;">phone</i></div>
                        <input type="text" name="cptelp" id="CpTelp">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Deskripsi Agenda <i class="material-icons left" style="color: black;">message</i></div>
                        <textarea style="height: 10vh;" name="descTxt" id="DescTxt" cols="30" rows="10"></textarea>
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Bahasa<i class="material-icons left" style="color: black;">language</i></div>
                        <select name="cbBahasa" id="CBbahasa">
                            <option value="1">Indonesia</option>
                            <option value="2">Inggris</option>
                        </select>
                    </div><br>
                    <div class="input-field" id ="baba">
                    <div class="judul">Judul yang di Translate<i class="material-icons left" style="color: black;">class</i></div>
                        <select name="cbTranslate" id="CBtranslate">
                              <option value="-1">Klik di sini jika mau translate</option>
                                <?php
                                    for($i=0; $i<Count($agendaid); $i++){
                                ?>
                                <option value="<?= $agendaid[$i]?>"><?= $judulagenda[$i]?></option>
                            <?php } ?> 
                        </select>
                        
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Tag<i class="material-icons left" style="color: black;">class</i></div>
                        <select name="cbTag" id="CBtag">
                            <option value="-1">Silahkan pilih tag</option>
                            <?php  
                                $query3 = "SELECT * FROM TAG";
                                $list3 = $conn->query($query3);
                                foreach ($list3 as $key => $value) {
                                        $tagid = $value['tag_id'];
                                        $query4 = "SELECT * FROM TAG_BAHASA WHERE TAG_ID = '$tagid'";
                                        $list4 = $conn->query($query4);
                                        foreach ($list4 as $key => $val) {
                                    ?>
                                    <option value="<?= $val['tag_id']?>"><?= $val['tag_nama']?></option>
                            <?php }} ?> 
                            </select>
                    </div><br>
                    <form method="post" action="" enctype="multipart/form-data" id="myform">
                        <div class='preview'>
                            <img src="Image/non.jpg" id="img" width="100" height="100">
                        </div>
                        <div class="input-field">
                            <div class="judul">Pilih Gambar<i class="material-icons left" style="color: black;">photo</i></div>
                            <input type="file" id="file" name="file"/>
                        </div>
                    </form>
                    <button class="waves-effect waves-light btn-large" type="submit" value="submit" id="btnInsert">Submit <i class="material-icons right">send</i></button>
                    <br>
                </div>
            </div>
        </div>
    </div>
    <div style="overflow: auto;width: 100vw;height: 100vh;" class="table"></div>
<?php 
} 
else if($action == 1){ 
    foreach ($list as $key => $value) {
        foreach ($list2 as $key => $value2) {
?>
    <div class="row agenda">
        <div class="col s12">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>CRUD Agenda --- UBAH</h2>
                </div>
                <div class="card-content">
                    <div class="input-field">
                    <div class="judul">Judul Agenda <i class="material-icons left" style="color: black;">title</i></div>
                        <input type="text" name="judulTxt" id="JudulTxt" value="<?= $value2['agenda_judul']?>">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Lokasi<i class="material-icons left" style="color: black;">location_on</i></div>
                        <input type="text" name="lokasi" id="Lokasi" value="<?= $value['agenda_lokasi']?>">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Contact Person Email<i class="material-icons left" style="color: black;">email</i></div>
                        <input type="text" name="cpemail" id="CpEmail" value="<?= $value['agenda_cpemail']?>">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Contact Person Telp<i class="material-icons left" style="color: black;">phone</i></div>
                        <input type="text" name="cptelp" id="CpTelp" value="<?= $value['agenda_cptelp']?>">
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Deskripsi Agenda <i class="material-icons left" style="color: black;">message</i></div>
                        <textarea style="height: 10vh;" name="descTxt" id="DescTxt" cols="30" rows="10"><?= $value2['agenda_deskripsi']?></textarea>
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Bahasa<i class="material-icons left" style="color: black;">language</i></div>
                    <div class="judul">Bahasa Sebelumnya: 
                        <?php foreach ($list2 as $key => $value) {
                            $tmp = $value['bahasa_id'];
                            if($tmp == 1){ echo "Indonesia";}else{ echo "Inggris";}
                        } ?>
                        
                    </div><br>
                    <div class="input-field">
                    <div class="judul">Tag<i class="material-icons left" style="color: black;">class</i></div>
                    <div class="judul">Tag Sebelumnya:
                        <?php 
                            $tagnama='';    
                            $query = "SELECT * FROM konten_tag where konten_id=1 and konten_parent = $idx";
                            $list = $conn->query($query);
                            foreach ($list as $key => $val) {
                            $tmp = $val['tag_id'];
                            $query2 = "SELECT * FROM tag_bahasa where tag_id = $tmp";
                            $list2 = $conn->query($query2);
                            foreach ($list2 as $key => $val2) {
                                $tagnama = $val2['tag_nama'];
                            }
                            echo $tagnama;
                        
                        } ?>
                        <i class="material-icons left" style="color: black;">class</i></div>
                        <select name="cbTag" id="CBtag">
                            <?php  
                                $query3 = "SELECT * FROM TAG";
                                $list3 = $conn->query($query3);
                                foreach ($list3 as $key => $value) {
                                        $tagid = $value['tag_id'];
                                        $query4 = "SELECT * FROM TAG_BAHASA WHERE TAG_ID = '$tagid'";
                                        $list4 = $conn->query($query4);
                                        foreach ($list4 as $key => $val) {
                            ?>
                                <option value="<?= $val['tag_id']?>"><?= $val['tag_nama']?></option>
                            <?php }} ?> 
                        </select>
                    </div><br>
                    <form method="post" action="" enctype="multipart/form-data" id="myform">
                        <div class='preview'>
                                <img src="" id="img" width="100" height="100">
                            
                        </div>
                        <div class="input-field">
                            <div class="judul">Pilih Gambar<i class="material-icons left" style="color: black;">photo</i></div>
                            
                            <input type="file" id="file" name="file"/>
                        </div>
                    </form>

                    <button class="waves-effect waves-light btn-large" type="submit" value="<?= $dataid ?>" id="btnUpdate">Update <i class="material-icons right">send</i></button>
                    <button class="waves-effect waves-light btn-large" type="submit" id="btnCancel"><a class="nounderline" href="admin.php">Cancel <i class="material-icons right">send</i></a></button>
                    <input type="file" id="upload" style="display:none" value="<?php echo $var ?>">
                </div>
            </div>
        </div>
    </div>
<?php        
    }}} else{ 
        foreach ($list2 as $key => $value) {       
?>
    <div class="row agenda">
        <div class="col s12">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>CRUD Agenda --- HAPUS</h2>
                </div>
                <div class="card-content">
                    <div class="judul">Apakah Anda yakin Menghapus Data dengan: <i class="material-icons left" style="color: black;">title</i></div>
                    <div class="judul">Judul Agenda <i class="material-icons left" style="color: black;">title</i></div>
                    <input disabled type="text" name="judulTxt" id="JudulTxt" value="<?= $value['agenda_judul']?>">
                    <button class="waves-effect waves-light btn-large" type="submit" value="<?= $dataid ?>" id="btnDelete">Delete <i class="material-icons right">send</i></button>
                    <button class="waves-effect waves-light btn-large" type="submit" id="btnCancel"><a class="nounderline" href="admin.php">Cancel <i class="material-icons right">send</i></a></button>
                </div><br>
                <br>
            </div>
        </div>
    </div>
    <?php }}?>
</body>
</html>
<script>
    $('.table').load('agendaTable.php');
    
    $(document).ready(function(){
        $("#baba").hide();
        $("#CBbahasa").change(function(){
            var selectedCountry = $(this).children("option:selected").val();
            if(selectedCountry == 1){
                $("#baba").hide();
                translate ="-1";
            } else{
                $("#baba").show();            
            }
        });
       
        $("select").formSelect();
        $("#btnInsert").click(function (){
            translate = $("#CBtranslate").val();
            let judul = $('#JudulTxt').val();
            let desc = $('#DescTxt').val();
            let bhs = $('#CBbahasa').val();
            let cptelp = $('#CpTelp').val();
            let cpemail = $('#CpEmail').val();
            let lokasi = $('#Lokasi').val();
            let tag = $('#CBtag').val();
            var srcs ="";
            var fd = new FormData();
            var files = $('#file')[0].files[0];
            fd.append('file',files);
            if(judul != "" && desc != ""){
                $.ajax({
                    url: 'uploadgambar.php',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    success: function(response){
                        if(response != 0){
                            $("#img").attr("src",response); 
                            $(".preview img").show(); 
                            srcs = $("#img").attr("src");
                            alert(srcs);
                            $.ajax({
                                url: "insertAgenda.php",
                                method: 'post',
                                data: {
                                    judul : judul,
                                    desc : desc,
                                    src : srcs,
                                    bhs : bhs,
                                    cpemail : cpemail,
                                    cptelp : cptelp,
                                    lokasi : lokasi,
                                    tag : tag,
                                    sourceid : translate
                                },
                                success: function(result){
                                    $('.table').load('agendaTable.php');   
                                    window.location.pathname ="proyek/admin.php"; 
                                    alert(result);
                                  
                                }
                            });
                        }else{
                            alert('file not uploaded');
                        }
                    }
                });
            }else{
                alert("Judul dan deskripsi nya harus terisi!");
            }
        });

        $("#btnUpdate").click(function (){
            let id = $(this).val();
            let judul = $('#JudulTxt').val();
            let desc = $('#DescTxt').val();
            let cptelp = $('#CpTelp').val();
            let cpemail = $('#CpEmail').val();
            let lokasi = $('#Lokasi').val();
            let tag = $('#CBtag').val();
            var srcs ="";
            var fd = new FormData();
            var files = $('#file')[0].files[0];
            fd.append('file',files);
            if(judul != "" && desc != ""){
                $.ajax({
                    url: 'uploadgambar.php',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    success: function(response){
                        if(response != 0){
                            $("#img").attr("src",response); 
                            $(".preview img").show(); // Display image element
                            srcs = $("#img").attr("src");
                            alert(srcs);
                            $.ajax({
                                url: "editAgenda.php",
                                method: 'post',
                                data: {
                                    id : id,
                                    judul : judul,
                                    desc : desc,
                                    src : srcs,
                                    cpemail : cpemail,
                                    cptelp : cptelp,
                                    lokasi : lokasi,
                                    tag : tag 
                                },
                                success: function(result){
                                    $('.table').load('agendaTable.php');
                                    window.location.pathname ="proyek/admin.php";
                                    alert(result);
                                }
                            });
                        }else{
                            alert('file not uploaded');
                        }
                    }
                });
            }else{
                    alert("Judul dan deskripsi nya harus terisi!");
                }
        });

        $("#btnDelete").click(function (){
            let id = $(this).val();
            $.ajax({
                url: "deleteAgenda.php",
                method: 'post',
                data: {
                    id : id  
                },
                success: function(result){
                    window.location.pathname ="proyek/admin.php";
                    alert(result);
                }
            });
        });

    });
</script>
