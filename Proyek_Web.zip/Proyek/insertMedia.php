<?php
    require_once("Connection.php");

    $judul = $_POST["judul"];
    $desc = $_POST["desc"];
    $tajuk = $_POST["tajuk"];
    $hal = $_POST["hal"];
    $stgl = $_POST["stgl"];
    $tag = $_POST["tag"];
    $tmpbhs = $_POST["bhs"];
    $src = $_POST["src"];
    $tgl = date("Y-m-d H:i:s");
    $bhs = (int)$tmpbhs;
    $sourceid = $_POST['sourceid'];
    $translate = (int)$sourceid;
    
    $konten = 3;
    if($translate == -1){
        $query2 = "INSERT INTO media VALUES('','$src','$tgl','$tajuk','$hal','$stgl',1)";
        if($conn->query($query2)== true){
            $id ="";
            $res  = mysqli_query($conn, "select * from media order by media_tanggal");
            foreach($res as $key=>$data){
                $id = $data['media_id'];
            }
            if($id != ""){
                if($tag != "-1"){
                    $query = "INSERT INTO media_bahasa VALUES('',$id,$bhs,'$judul','$desc')";
                    $query3 = "INSERT INTO konten_tag VALUES($konten, $id, $tag)";
                    if($conn->query($query) == true && $conn->query($query3) == true){
                        echo "Berhasil Menambahkan Data";
                    }else{
                        echo "Tidak Berhasil Menambahkan Data";
                    } 
                } else{
                    $query = "INSERT INTO media_bahasa VALUES('',$id,$bhs,'$judul','$desc')";
                    if($conn->query($query) == true ){
                        echo "Berhasil Menambahkan Data";
                    }else{
                        echo "Tidak Berhasil Menambahkan Data";
                    } 
                }
            } else {
                echo "Tidak Berhasil Menambahkan Data";
            }
        } else {
            echo "Tidak Berhasil Menambahkan Data";
        }

    }else{
        $query5 = "SELECT * FROM media_BAHASA WHERE media_ID=$translate and bahasa_id= 2";
        $list = $conn->query($query5);
        $rowcount = mysqli_num_rows($list);
        if($rowcount > 0){
            echo "Data Translate sudah ada";
        }else{          
            $query = "INSERT INTO media_bahasa VALUES('',$id,$bhs,'$judul','$desc')";
            if($conn->query($query) == true){
                echo "Berhasil Mentranslate Data";
            }else{
                echo "Tidak Berhasil Mentranslate Data";
            } 
        }
    }
?>