<?php 
    $judultab ="";
    $judultab = $_GET['urlpage'];
    if($judultab == "Arsip"){
        $judultab = $judultab. " Berita";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .banner{
            position:absolute;
            z-index:12;
            width:100%;
            left:0;
            height: 45vh;
            background-color:rgba(0,0,0,0.8);
            padding-top:26vh;
            margin-bottom: 50vh;
        }
        .bgbanner{
            height: 45vh;
            width:100%;
            object-fit: cover;
            object-position: 20% 10px; 
        }
        #title{
            font-weight: bold;
            color:white;
            text-align: center;
            font-size: 30pt;
            padding-top:4vh;
        }
    </style>
</head>
<body>
    <img src="Image/2.jpg" class="bgbanner" style=" position: absolute;left:0;"> 
    <div class="banner"><div id="title"><h1><?php echo $judultab; ?></h1></div></div>
    <br><br><br><br><br><br><br><br><br><br>
</body>
</html>
<script>
    $(document).ready(function () {
        $("#title").textillate();
    });
</script>