<?php
  require_once("Connection.php");
  require_once("Sumber.php"); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .parallax-container{
        height: 60vh;
    }

    section{
        width: 100%;
        min-height: 350px;
    }

    section .content{
        max-width: 1000px;
        margin: 0 auto;
    }

    .teks1{
        text-indent: 50px;
        font-size: 16pt;
        text-align: justify;
    }

    h1 a{
        color: black;
    }

    h1 a:hover { 
        -webkit-background-clip: text;
        color: white;
        -webkit-text-fill-color: transparent;
        background-image: -webkit-gradient(linear, left top, right top, from(#ea8711), to(#d96363));
        background-image: -webkit-linear-gradient(left, #ea8711, #d96363, #73a6df, #9085fb, #52ca79); 
        background-image:    -moz-linear-gradient(left, #ea8711, #d96363, #73a6df, #9085fb, #52ca79);
        background-image:     -ms-linear-gradient(left, #ea8711, #d96363, #73a6df, #9085fb, #52ca79); 
        background-image:      -o-linear-gradient(left, #ea8711, #d96363, #73a6df, #9085fb, #52ca79);
    }

    body{
        background-color:rgb(243,243,243);
    }
</style>
<body>
    <?php include("Header.php"); ?>
    <?php include("minioverlay.php"); ?>
   
    <div class="container" style="margin-top:20vh;margin-bottom:40px;">
        <?php $query="SELECT * FROM JURUSAN";
            $list = $conn->query($query);
            foreach ($list as $key => $val) {
                $jurid = $val['jurusan_id'];
                $query2="SELECT * FROM JURUSAN_BAHASA WHERE JURUSAN_ID='$jurid'";
                $list2 = $conn->query($query2);
                foreach ($list2 as $key => $value) {
        ?>
        <div class="parallax-container">
        <div class="parallax"><img src=<?=$val['jurusan_gambar']?>></div>
        </div>
        <section>
            <div class="content">
                <h1><a href=<?=$val['jurusan_website']?>><?= $value['jurusan_nama']?></a></h1>
                <button class="waves-effect waves-light btn-large" style="border-radius: 50px;" type="submit" value="<?=$val['jurusan_id'];?>" name="jurusan"><a class="nounderline" href="Matkul.php?urlpage=Mata Kuliah&jurusan=<?= $val['jurusan_id']; ?>">Mata Kuliah</a></button>
                <p class="teks1"><?=$value['jurusan_deskripsi']?></p>
            </div>
        </section>
        <?php     
            }}
        ?>
    </div>
    <?php include("Footer.php"); ?>
</body>
</html>
<script>
    $(document).ready(function(){
        $('.parallax').parallax();
    });
</script>