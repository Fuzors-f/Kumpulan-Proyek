<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $judul = $_POST["judul"];
    $desc = $_POST["desc"];
    $cpemail = $_POST["cpemail"];
    $cptelp = $_POST["cptelp"];
    $lokasi = $_POST["lokasi"];
    $tag = $_POST["tag"];
    $src = $_POST["src"];
    $tgl = date("Y-m-d H:i:s");

    $quwery = "SELECT * from AGENDA_BAHASA WHERE agenda_bahasa_id = $id";
    $list = $conn->query($quwery);
    $agendab = '';
    foreach ($list as $key => $value) {
        $agendab = $value['agenda_id'];
    }
    $query2 = "UPDATE AGENDA SET agenda_foto='$src', agenda_tgl='$tgl', agenda_lokasi='$lokasi', agenda_cpemail='$cpemail', agenda_cptelp='$cptelp' WHERE agenda_id='$agendab'";
    if($id != ""){
        $querys = "UPDATE KONTEN_TAG SET TAG_ID = $tag WHERE KONTEN_PARENT= $agendab AND KONTEN_ID=1";
        $query = "UPDATE AGENDA_BAHASA SET agenda_id='$agendab', agenda_judul='$judul', agenda_deskripsi='$desc' WHERE agenda_bahasa_id='$id'";
        if($conn->query($query) == true && $conn->query($querys) == true){
            echo "Berhasil Mengupdate Data";
        }else{
            echo "Tidak Berhasil Mengupdate Data";
        } 
    } else {
        echo "Tidak Berhasil Mengupdate Data";
    }  
?>