<?php 
    session_start();
    if($_POST['action']=="1"){
        $_SESSION['bahasa'] = 1;
        echo $_SESSION['bahasa'];
    } else{
        $_SESSION['bahasa'] = 2;
        echo $_SESSION['bahasa'];
    }
?>