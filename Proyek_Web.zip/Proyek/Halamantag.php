<?php 
    require_once("Connection.php"); 
    $idtag = $_GET['id'];
    $tmpid =[];
    $tagnam =[];
   //echo "<script>alert(".$id.")</script>";
   $query = "select * from tag ";
   $rs = mysqli_query($conn,$query);
   foreach ($rs as $key => $value) {
     # code...
     if($value['tag_id'] != $idtag){
      $tmpid[Count($tmpid)] = $value['tag_id'];
     }
   }

   for($i=0;$i<Count($tmpid);$i++){
     $qw = "Select * from tag_bahasa where tag_id = $tmpid[$i]";
     $res = mysqli_query($conn,$qw);
     foreach($res as $key=>$data){
       $tagnam[Count($tagnam)] = $data['tag_nama'];
     }
   }
  var_dump($tagnam);
  var_dump($tmpid);
?>


<!DOCTYPE html>
<html lang="en">
<head>    
</head>

<body>
    <?php include("Header.php"); ?>
    <style>
          .tabs .tab a{
            color:#000;
            font-size: 16pt;
            font-family: Arial, Helvetica, sans-serif;
            } /*Black color to the text*/

            .tabs .tab a:hover {
                background-color:#eee;
                color:#000;
            } /*Text color on hover*/
            .tabs .tab a.active {
                background-color:rgba(0,0,0,0.5);
                    color:#000;
                }
                .tabs .tab a:focus.active {
                background-color:rgba(0,0,0,0.5);
                    color:#000;
            }/*Background and text color when a tab is active*/
            .tabs .indicator {
                background-color:#000;
            } /*Color of underline*/
            h1 a.ck{
              color: gray;
            }
            h1 a.ck:hover{
              color: blue;
            }
        </style>
    <?php include("minioverlay.php"); ?>
    <div class="container" style="margin-top: 150px;">
       <div style="font-size:14pt;"> Kumpulan Arsip tentang <?php echo " ".$judultab;?>. <span>Cek tag lainya : <a class='dropdown-trigger btn' href='#' data-target='dropdown1' style="margin-left:5px;background-color:gray; color:white;width:150px;">Cek disini</a></span> </div>
       <ul id='dropdown1' class='dropdown-content' >
        <?php 
          for($i=0;$i<Count($tmpid);$i++){
            echo "<li><a href= 'Halamantag.php?urlpage=".$tagnam[$i]."&id=".$tmpid[$i]."'>".$tagnam[$i]."</a></li>";
          }
        ?>
      </ul>
       <hr style ="border: 2px solid  gray;">
    </div>

    <div style="width:100%; height: auto;">
        <div class="container" style="margin-top:20px;">
          <div class="row">
              <div class="col s12">
                <ul class="tabs" >
                  <li class="tab col s3" ><a class="active nounderline" id="berita" href="#test1-swipe-1">Berita</a></li>
                  <li class="tab col s3" ><a  href="#test2-swipe-2" id="agenda" class="nounderline">Agenda</a></li>
                  <li class="tab col s3" ><a href="#test3-swipe-3" id="media" class="nounderline">Media</a></li>
                </ul>
              </div>
              <div id="test1-swipe-1" class="col s12" style="margin-top: 40px;padding-top: 20px;">
                <?php 
              //  echo $id;
                  $kumpulan =[];
                  $query ="SELECT * FROM konten_tag where konten_id = 2 AND tag_id =$idtag";
                  $res = mysqli_query($conn, $query);
                  foreach($res as $key=>$data){
                      $kumpulan[Count($kumpulan)] = $data['konten_parent'];
                  }
                  $idberita =[];
                  $judul_berita =[];
                  for($i=0; $i<Count($kumpulan); $i++){
                    $query2 = "SELECT * FROM berita_bahasa where berita_id = $kumpulan[$i] and bahasa_id =1";
                    $result = mysqli_query($conn, $query2);
                    foreach($result as $key=>$data){
                      $judul_berita[Count($judul_berita)] = $data['berita_judul'];
                      $idberita[Count($idberita)]= $data['berita_id'];
                    }

                  }


                for($i=0; $i<Count($judul_berita); $i++){
                
                ?>
                    <h1><a  class="ck nounderline" href="HalamanBerita.php?urlpage=Berita&id=<?php echo $idberita[$i]?>"><?php echo $judul_berita[$i]?></a></h1>

                <?php }?>
              </div>
              <div id="test2-swipe-2" class="col s12"style="margin-top: 40px;">
                
              <?php 
                  $kumpulan =[];
                 // echo $id;
                  $query ="SELECT * FROM konten_tag where konten_id=1 and tag_id =$idtag";
                  $res = mysqli_query($conn, $query);
                  foreach($res as $key=>$data){
                      $kumpulan[Count($kumpulan)] = $data['konten_parent'];
                  }
            
                  $idagenda =[];
                  $judul_agenda =[];
                  for($i=0; $i<Count($kumpulan); $i++){
                    $query2 = "SELECT * FROM agenda_bahasa where agenda_id = $kumpulan[$i] and bahasa_id =1";
                    $result = mysqli_query($conn, $query2);
                    foreach($result as $key=>$data){
                      $judul_agenda[Count($judul_agenda)] = $data['agenda_judul'];
                      $idagenda[Count($idagenda)]= $data['agenda_id'];
                    }

                  }


                for($i=0; $i<Count($judul_agenda); $i++){
                
                ?>
                    <h1><a  class="ck nounderline" href="HalamanAgenda.php?urlpage=Agenda&id=<?php echo $idagenda[$i]?>"><?php echo $judul_agenda[$i]?></a></h1>

                <?php }?>
                
              </div>
              <div id="test3-swipe-3" class="col s12"style="margin-top: 40px;">
              <?php 
                  $kumpulan =[];
                  $query ="SELECT * FROM konten_tag where konten_id = 2 and tag_id =$idtag";
                  $res = mysqli_query($conn, $query);
                  foreach($res as $key=>$data){
                      $kumpulan[Count($kumpulan)] = $data['konten_parent'];
                  }

                  $idmedia =[];
                  $judul_media =[];
                  for($i=0; $i<Count($kumpulan); $i++){
                    $query2 = "SELECT * FROM media_bahasa where media_id = $kumpulan[$i] and bahasa_id =1";
                    $result = mysqli_query($conn, $query2);
                    foreach($result as $key=>$data){
                      $judul_media[Count($judul_media)] = $data['media_judul'];
                      $idmedia[Count($idmedia)]= $data['media_id'];
                    }

                  }


                for($i=0; $i<Count($judul_media); $i++){
                
                ?>
                    <h1><a  class="ck nounderline" href="HalamanMedia.php?urlpage=Media&id=<?php echo $idmedia[$i]?>"><?php echo $judul_agenda[$i]?></a></h1>

                <?php }?>
              </div>
          </div>
        </div>
      </div>
    <?php include("footer.php");?>
</body>
</html>
<script>
     $('.tabs').tabs();
</script>