<?php
    require_once("Connection.php");
    
    $judul = $_POST["judul"];
    $desc = $_POST["desc"];
    $tmpbhs = $_POST["bhs"];
    $cpemail = $_POST["cpemail"];
    $cptelp = $_POST["cptelp"];
    $lokasi = $_POST["lokasi"];
    $tag = $_POST["tag"];
    $src = $_POST["src"];
    $tgl = date("Y-m-d H:i:s");
    $bhs = (int)$tmpbhs;
    $sourceid = $_POST['sourceid'];
    $translate = (int)$sourceid;

    $konten = 1;
    if($translate == -1){
        $query2 = "INSERT INTO agenda VALUES('','$src','$tgl','$lokasi','$cpemail','$cptelp',1)";
        if($conn->query($query2)== true){
            $id ="";
            $res  = mysqli_query($conn, "select * from agenda order by agenda_tgl ");
            foreach($res as $key=>$data){
                $id = $data['agenda_id'];
            }
            if($id != ""){
                if($tag != "-1"){
                    $query = "INSERT INTO agenda_bahasa VALUES('',$id,$bhs,'$judul','$desc')";
                    $query3 = "INSERT INTO konten_tag VALUES($konten, $id, $tag)";
                    if($conn->query($query) == true && $conn->query($query3) == true){
                        echo "Berhasil Menambahkan Data";
                    }else{
                        echo "Tidak Berhasil Menambahkan Data";
                    } 
                } else{
                    $query = "INSERT INTO agenda_bahasa VALUES('',$id,$bhs,'$judul','$desc')";
                    if($conn->query($query) == true ){
                        echo "Berhasil Menambahkan Data";
                    }else{
                        echo "Tidak Berhasil Menambahkan Data";
                    } 
                }
            } else {
                echo "Tidak Berhasil Menambahkan Data";
            }
        } else {
            echo "Tidak Berhasil Menambahkan Data";
        }

    }else{
        $query5 = "SELECT * FROM AGENDA_BAHASA WHERE AGENDA_ID=$translate and bahasa_id= 2";
        $list = $conn->query($query5);
        $rowcount = mysqli_num_rows($list);
        if($rowcount > 0){
            echo "Data Translate sudah ada";
        }else{          
            $query = "INSERT INTO agenda_bahasa VALUES('',$translate,$bhs,'$judul','$desc')";
            if($conn->query($query) == true){
                echo "Berhasil Mentranslate Data";
            }else{
                echo "Tidak Berhasil Mentranslate Data";
            } 
        }
    }
    
?>