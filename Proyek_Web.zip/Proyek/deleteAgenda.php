<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $quwery = "SELECT * from AGENDA_BAHASA WHERE agenda_bahasa_id = $id";
   
    $list = $conn->query($quwery);
    $agendab = '';
    foreach ($list as $key => $value) {
        $agendab = $value['agenda_id'];
    }
    
    $qwery2 = "SELECT * FROM KONTEN_TAG WHERE KONTEN_PARENT = $agendab";
    $list3 = $conn->query($qwery2);
    $rowcount2 = mysqli_num_rows($list3);
    if($rowcount2 > 0){
        $query2 = "DELETE FROM KONTEN_TAG WHERE KONTEN_PARENT = $agendab";
        if($conn->query($query2) == true){
            echo "Berhasil Menghapus Data di Konten_tag";
        }else{
            echo "Tidak Berhasil Menghapus Data di Konten_tag";
        }
    }

    $qwery = "SELECT * FROM AGENDA_BAHASA WHERE AGENDA_ID = $agendab";
    $list2 = $conn->query($qwery);
    $rowcount = mysqli_num_rows($list2);
    if($rowcount > 1){
        $query = "DELETE FROM AGENDA_BAHASA WHERE AGENDA_BAHASA_ID='$id'";
        
        if($conn->query($query) == true){
            echo "Berhasil Menghapus Data (Translate)";
        }else{
            echo "Tidak Berhasil Menghapus Data (Translate)";
        }
    }else{
        $query = "DELETE FROM AGENDA_BAHASA WHERE AGENDA_ID='$agendab'";
        $query2 = "DELETE FROM AGENDA WHERE AGENDA_ID='$agendab'"; //351

        if($conn->query($query) == true && $conn->query($query2)== true){
            echo "Berhasil Menghapus Data Utama";
        }else{
            echo "Tidak Berhasil Menghapus Data Utama";
        } 
    }
?>