<?php 
    require_once("Connection.php"); 
    $tanggal = [];
    $query  = "select agenda_tgl from agenda";
    $res = mysqli_query($conn, $query);
    foreach($res as $key=>$data){
        $parts = explode('-', $data['agenda_tgl']);
        $tahun = $parts[0];
        $cek = false;
        for($i=0; $i<Count($tanggal); $i++){
            if($tanggal[$i] == $tahun){
                $cek = true;
            } 
        }
        if($cek == false){
            $tanggal[Count($tanggal)] = $tahun;
        }
    }

    $query2 = "select berita_tanggal from berita";
    $res2 = mysqli_query($conn, $query2);
    foreach($res2 as $key=>$data){
        $parts = explode('-', $data['berita_tanggal']);
        $tahun = $parts[0];
        $cek = false;
        for($i=0; $i<Count($tanggal); $i++){
            if($tanggal[$i] == $tahun){
                $cek = true;
            } 
        }
        if($cek == false){
            $tanggal[Count($tanggal)] = $tahun;
        }
    }

    $query3 = "select media_tanggal from media";
    $res3 = mysqli_query($conn, $query3);
    foreach($res3 as $key=>$data){
        $parts = explode('-', $data['media_tanggal']);
        $tahun = $parts[0];
        $cek = false;
        for($i=0; $i<Count($tanggal); $i++){
            if($tanggal[$i] == $tahun){
                $cek = true;
            } 
        }
        if($cek == false){
            $tanggal[Count($tanggal)] = $tahun;
        }
    }
    for($i = Count($tanggal)-1; $i>=0; $i--){
        for($j=1; $j<=Count($tanggal)-1; $j++){
            if($tanggal[$j-1] > $tanggal[$j]){
                $tmp = $tanggal[$j-1] ;
                $tanggal[$j-1] = $tanggal[$j];
                $tanggal[$j] = $tmp;
            }
        }
    }
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Proyek.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="materialize/js/materialize.min.js"></script>
    <style>
        .searchbox{
            background-color: white;
            height: auto;
            width: 350px;
            padding:20px;

        }
        
        /*the container must be positioned relative:*/
        .custom-select {
            position: relative;
            font-family: Arial;
        }

        .custom-select select {
             display: none; /*hide original SELECT element:*/
        }

        .select-selected {
             background-color: rgb(30,30,30);
        }

        /*style the arrow inside the select element:*/
        .select-selected:after {
            position: absolute;
            content: "";
            top: 14px;
            right: 10px;
            width: 0;
            height: 0;
            border: 6px solid transparent;
            border-color: #fff transparent transparent transparent;
        }

        /*point the arrow upwards when the select box is open (active):*/
        .select-selected.select-arrow-active:after {
            border-color: transparent transparent #fff transparent;
            top: 7px;
        }

        /*style the items (options), including the selected item:*/
        .select-items div,.select-selected {
            color: #ffffff;
            padding: 8px 16px;
            border: 1px solid transparent;
            border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
            cursor: pointer;
            user-select: none;
        }

        /*style items (options):*/
        .select-items {
            position: absolute;
            background-color: rgb(30,30,30);
            top: 100%;
            left: 0;
            right: 0;
            z-index: 99;
        }

        /*hide the items when the select box is closed:*/
        .select-hide {
            display: none;
        }

        .select-items div:hover, .same-as-selected {
             background-color: rgba(0, 0, 0, 0.1);
        }

        .newsbox{
          width:350px;
          height:100px;
          padding-left: 10px;
          background-color:white; 
          padding-top:22px;
          padding-left: 15px;
          margin-left: 15px;
          margin-top: 10px;
          margin-bottom: 10px;
          font-size: 10pt;
          color: black;
        
      }
    </style>
</head>
<body>
    <div style="background-color:rgb(243,243,243);">
      <?php include("Header.php"); ?>
      <?php include("minioverlay.php"); ?>
        <div class="container" style="margin-left:10vw;margin-bottom: 2vh; margin-top: 24vh;padding:20px; font-size:20pt;" >
            "Merupakan Arsip tempat disimpanya berkas"
            <hr style="border-top: 2px solid gray;">
        </div>
        <div class="container" style="margin-left:10vw;margin-bottom: 5vh">
            <div class="row">
                    <div class="col s4">
                        <div class="searchbox">
                            <h1 style="margin-left: 15px;">Filter</h1>
                            Jenis : 
                            <div class="custom-select" style="width:200px;">
                                    <select name = "jenis" id="jenis">
                                        <option value="0">Berita</option>
                                        <option value="1">Agenda</option>
                                        <option value="3">Media</option>
                                    </select>
                            </div>
                            <br>
                            Tahun : 
                            <div class="custom-select" style="width:200px;">
                                    <select name = "tahun" id="tahun">
                                        <option value="0">Silahkan Pilih tahun</option>
                                        <?php 
                                            for($i=0; $i<Count($tanggal); $i++){
                                        ?>
                                             <option value="<?php echo $tanggal[$i]?>"><?php echo $tanggal[$i]?></option>
                                        <?php
                                            }
                                        
                                        ?>
                                    </select>
                            </div> <br>
                            Bulan :
                            <div class="custom-select" style="width:200px;">
                                    <select name = "bulan" id="bulan">
                                        <option value="0">Silahkan Pilih Bulan</option>
                                        <option value="01">Januari</option>
                                        <option value="02">Februari</option>
                                        <option value="03">Maret</option>
                                        <option value="04">April</option>
                                        <option value="05">Mei</option>
                                        <option value="06">Juni</option>
                                        <option value="07">Juli</option>
                                        <option value="08">Agustus</option>
                                        <option value="09">September</option>
                                        <option value="10">Oktober</option>
                                        <option value="11">November</option>
                                        <option value="12">November</option>
                                    </select>
                            </div><br>
                            

                        </div>
                        
                    </div>
                    <div class="col s8" id="spacerbox" ></div>
                   
            </div>
        </div>
        <?php include("Footer.php"); ?>
    </div>
    
</body>
</html>

<script>
var x, i, j, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
for (i = 0; i < x.length; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < selElmnt.length; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        h = this.parentNode.previousSibling;
        for (i = 0; i < s.length; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            for (k = 0; k < y.length; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        var isi ="";
        var jenis = "";
        var bulan = "";
        isi = $("#tahun").val();
        jenis = $("#jenis").val();
        bulan = $("#bulan").val();
        if(bulan !="0" && isi != "0"){
            $.ajax({
                url: "Controller.php",
                method: "post",
                data: {
                    tahun : isi,
                    jenis : jenis,
                    bulan : bulan
                },
                success: function(result){
                   
                  $("#spacerbox").html(result);
                }
            });
        } else{
            $('#spacerbox').html("");
            $("#spacerbox").load("Refreshberita.php");
        }
       
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  for (i = 0; i < y.length; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < x.length; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}


/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);



$(document).ready(function(){  
       $("#spacerbox").load("Refreshberita.php");
});
</script>

