<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $quwery = "SELECT * from media_BAHASA WHERE media_bahasa_id = $id";
   
    $list = $conn->query($quwery);
    $mediab = '';
    foreach ($list as $key => $value) {
        $mediab = $value['media_id'];
    }
    
    $qwery2 = "SELECT * FROM KONTEN_TAG WHERE KONTEN_PARENT = $mediab";
    $list3 = $conn->query($qwery2);
    $rowcount2 = mysqli_num_rows($list3);
    if($rowcount2 > 0){
        $query2 = "DELETE FROM KONTEN_TAG WHERE KONTEN_PARENT = $mediab";
        if($conn->query($query2) == true){
            echo "Berhasil Menghapus Data di Konten_tag";
        }else{
            echo "Tidak Berhasil Menghapus Data di Konten_tag";
        }
    }

    $qwery = "SELECT * FROM media_BAHASA WHERE media_ID = $mediab";
    $list2 = $conn->query($qwery);
    $rowcount = mysqli_num_rows($list2);
    if($rowcount > 1){
        $query = "DELETE FROM media_BAHASA WHERE media_BAHASA_ID='$id'";
        
        if($conn->query($query) == true){
            echo "Berhasil Menghapus Data (Translate)";
        }else{
            echo "Tidak Berhasil Menghapus Data (Translate)";
        }
    }else{
        $query = "DELETE FROM media_BAHASA WHERE media_ID='$mediab'";
        $query2 = "DELETE FROM media WHERE media_ID='$mediab'"; //351

        if($conn->query($query) == true && $conn->query($query2)== true){
            echo "Berhasil Menghapus Data Utama";
        }else{
            echo "Tidak Berhasil Menghapus Data Utama";
        } 
    }
?>