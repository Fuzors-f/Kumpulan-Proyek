<?php 
    require_once("Connection.php");
    $query = "select * from agenda";
    $res = mysqli_query($conn,$query);
    $fotoagenda ="";
    $idagenda ="";
   // session_start();
    $bahasa =0;
    if(isset($_SESSION['bahasa'])){
        $bahasa = $_SESSION['bahasa'];
    }
    foreach($res as $key=>$data){
        $idagenda = $data['agenda_id'];
        $fotoagenda = $data['agenda_foto'];
    } 
    $query2 = mysqli_query($conn,"select * from agenda_bahasa where agenda_id = $idagenda and bahasa_id = $bahasa");
    $judulagenda ="";
    $isiagenda ="";
    foreach($query2 as $key=>$data){
        $judulagenda = $data['agenda_judul'];
        $isiagenda = $data['agenda_deskripsi'];
    }
    

    $query = "select * from media";
    $res = mysqli_query($conn,$query);
    $fotomedia ="";
    $idmedia ="";
    foreach($res as $key=>$data){
        $idmedia = $data['media_id'];
        $fotomedia = $data['media_foto'];
    } 
    $query2 = mysqli_query($conn,"select * from media_bahasa where media_id = $idmedia and bahasa_id = $bahasa");
    $judulmedia ="";
    $isimedia ="";
    foreach($query2 as $key=>$data){
        $judulmedia = $data['media_judul'];
        $isimedia = $data['media_deskripsi'];
    }

    $query = "select * from berita";
    $res = mysqli_query($conn,$query);
    $fotoberita ="";
    $idberita ="";
    foreach($res as $key=>$data){
        $idberita= $data['berita_id'];
        $fotoberita = $data['berita_foto'];
    } 
    $query2 = mysqli_query($conn,"select * from berita_bahasa where berita_id = $idberita and bahasa_id = $bahasa");
    $judulberita ="";
    $isiberita ="";
    foreach($query2 as $key=>$data){
        $judulberita = $data['berita_judul'];
        $isiberita = $data['berita_deskripsi'];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2 class="header">Berita Terkini</h2>
    <hr style="border: 2px solid gray;">
    <div class="card horizontal">
      <div class="card-image">
      <img  src="<?php echo $fotoberita; ?>" onerror="this.onerror=null; this.src='Image/non.jpg'"  >
      </div>
      <div class="card-stacked">
        <div class="card-content" >
            <h1><?php echo $judulberita;?></h1>
        </div>
        <div class="card-action">
        <?php  echo "<a href='HalamanBerita.php?urlpage=Berita&id=".$idberita."' style='color:black;'>"?>
          Selengkapnya</a>
        </div>
      </div>
    </div>
    <br>
    <h2 class="header">Agenda Terbaru</h2>
    <hr style="border: 2px solid gray;">
    <div class="card horizontal">
      <div class="card-image">
            <img  src="<?php echo $fotoagenda; ?>" onerror="this.onerror=null; this.src='Image/non.jpg'"  >
      </div>
      <div class="card-stacked">
        <div class="card-content" >
            <h1><?php echo $judulagenda;?></h1>
        </div>
        <div class="card-action">
        <?php  echo "<a href='HalamanAgenda.php?urlpage=Agenda&id=".$idagenda."' style='color:black;'>"?>
          Selengkapnya</a>
        </div>
      </div>
    </div>
    <br>

    <h2 class="header">Media Terhangat</h2>
    <hr style="border: 2px solid gray;">
    <div class="card horizontal">
      <div class="card-image">
            <img  src="<?php echo $fotomedia; ?>" onerror="this.onerror=null; this.src='Image/non.jpg'"  >
      </div>
      <div class="card-stacked">
        <div class="card-content" >
            <h1><?php echo $judulmedia; ?></h1>
        </div>
        <div class="card-action">
          <?php  echo "<a href='HalamanMedia.php?urlpage=Media&id=".$idmedia."' style='color:black;'>"?>
          
          Selengkapnya</a>
        </div>
      </div>
    </div>
    <br>

</body>
</html>