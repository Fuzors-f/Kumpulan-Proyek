<?php
    require_once('Connection.php');
    require_once('Sumber.php');    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    thead tr th{
        padding: 10px;
        font-size: 16pt;
    }
    tbody tr td {
        padding: 15px;
    }
</style>
<body>
    <div class="row">
        <div class="col s12">
            <table class="centered highlight">
                <thead>
                    <tr>
                        <th>ID Berita</th>
                        <th>Judul Berita</th>
                        <th>Bahasa</th>
                        <th>Ubah</th>
                        <th>Hapus</tr>
                    </tr>
                    
                </thead>
                <tbody>
                    <?php 
                        $query=mysqli_query($conn,"SELECT * from berita_bahasa");
                        while($row = mysqli_fetch_assoc($query)){ ?>
                        <tr>
                            <td><?= $row['berita_bahasa_id']?></td>
                            <td><?= $row['berita_judul']?></td>
                            <td><?php if($row['bahasa_id'] == 1){ echo "Indonesia";}else{ echo "Inggris";}?></td>
                            <td><form action="Berita.php" method="post"><button class="waves-effect waves-light btn-small" name="btnEdit" type="submit" value="<?= $row['berita_bahasa_id']?>"><i class="material-icons">edit</i></button></form></td>
                            <td><form action="Berita.php" method="post"><button class="waves-effect waves-light btn-small" name="btnDelete" type="submit" value="<?= $row['berita_bahasa_id']?>"><i class="material-icons">delete</i></button></form></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>