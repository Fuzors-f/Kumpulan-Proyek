<?php
    require_once("Connection.php");
    require_once("Sumber.php");

    $judul = $_GET['urlpage'];
    $jurid = $_GET['jurusan'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .collapsible-header{
        
        font-size: 20pt;
    }

    thead tr th{
        font-size: 12pt
    }
    tbody tr td {
        font-size: 12pt
    }

    p{
        text-indent: 50px;
        text-align: justify;
    }

</style>
<body>
    <?php include("Header.php"); ?>
    <?php include("minioverlay.php"); ?>
    <div class="container" style="margin-top:20vh;margin-bottom:40px;">
        <h2>Mata Kuliah Apa Saja yang Dipelajari dalam Jurusan ini?</h2>
        <ul class="collapsible">
            <li>
            <div class="collapsible-header">SEMESTER 1</div>
                <div class="collapsible-body">
                    <?php
                        $query = "SELECT * FROM MATKUL WHERE JURUSAN_ID='$jurid' AND MATKUL_SEMESTER='1'";
                        $list = $conn->query($query);                     
                        $rowcount = mysqli_num_rows($list);
                        if($rowcount > 0){
                            foreach ($list as $key => $value) {
                                $id = $value['matkul_id'];
                                $query2 = "SELECT * FROM MATKUL_BAHASA WHERE MATKUL_ID='$id'";
                                $list2 = $conn->query($query2);
                                foreach ($list2 as $key => $val) { ?>
                    <h4>Mata Kuliah     : <b><?= $val['matkul_nama']?></b></h4>
                    <h4>Jumlah SKS      : <?= $value['matkul_sks']?></h4>
                    <h4>Deskripsi       : </h4><p><?= $val['matkul_deskripsi']?></p><br>
                    
                    <?php                
                                    
                                }
                            }
                        }   
                    ?>
                </div>
            </li>
            <li>
            <div class="collapsible-header">SEMESTER 2</div>
                <div class="collapsible-body">
                <?php
                        $query = "SELECT * FROM MATKUL WHERE JURUSAN_ID='$jurid' AND MATKUL_SEMESTER='2'";
                        $list = $conn->query($query);                     
                        $rowcount = mysqli_num_rows($list);
                        if($rowcount > 0){
                            foreach ($list as $key => $value) {
                                $id = $value['matkul_id'];
                                $query2 = "SELECT * FROM MATKUL_BAHASA WHERE MATKUL_ID='$id'";
                                $list2 = $conn->query($query2);
                                foreach ($list2 as $key => $val) { ?>
                    <h4>Mata Kuliah     : <b><?= $val['matkul_nama']?></b></h4>
                    <h4>Jumlah SKS      : <?= $value['matkul_sks']?></h4>
                    <h4>Deskripsi       : </h4><p><?= $val['matkul_deskripsi']?></p><br>
                    
                    <?php                
                                    
                                }
                            }
                        }   
                    ?>
                </div>
            </li>
            <li>
            <div class="collapsible-header">SEMESTER 3</div>
                <div class="collapsible-body">
                <?php
                        $query = "SELECT * FROM MATKUL WHERE JURUSAN_ID='$jurid' AND MATKUL_SEMESTER='3'";
                        $list = $conn->query($query);                     
                        $rowcount = mysqli_num_rows($list);
                        if($rowcount > 0){
                            foreach ($list as $key => $value) {
                                $id = $value['matkul_id'];
                                $query2 = "SELECT * FROM MATKUL_BAHASA WHERE MATKUL_ID='$id'";
                                $list2 = $conn->query($query2);
                                foreach ($list2 as $key => $val) { ?>
                    <h4>Mata Kuliah     : <b><?= $val['matkul_nama']?></b></h4>
                    <h4>Jumlah SKS      : <?= $value['matkul_sks']?></h4>
                    <h4>Deskripsi       : </h4><p><?= $val['matkul_deskripsi']?></p><br>
                    
                    <?php                
                                    
                                }
                            }
                        }   
                    ?>
                </div>
            </li>
        </ul>
    <button class="waves-effect waves-light btn-large" style="border-radius: 50px;" type="submit"><a class="nounderline" href="Jurusan.php?urlpage=Jurusan">Back</a></button>
    </div>
    <?php include("Footer.php"); ?>
</body>
</html>
<script>
    $(document).ready(function(){
        $('.collapsible').collapsible();
    });
</script>