<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $kumpkonten = [];
    $querys = "SELECT * FROM KONTEN_TAG WHERE TAG_ID = '$id'";
    $rs = mysqli_query($conn,$querys);
    foreach ($rs as $key => $value) {
        # code...
        $kumpkonten[Count($kumpkonten)] = $value['konten_parent'];
    }
    if(Count($kumpkonten)>0){
        for($i=0;$i<Count($kumpkonten);$i++){
            $querydel = "DELETE FROM konten_tag WHERE konten_parent= $kumpkonten[$i]";
            $rs = mysqli_query($conn,$querydel);
        }
    }
    $query = "DELETE FROM TAG_BAHASA WHERE TAG_ID='$id'";
    $query2 = "DELETE FROM TAG WHERE TAG_ID='$id'";

    if($conn->query($query) == true && $conn->query($query2)== true){
        echo "Berhasil Menghapus Data";
    }else{
        echo "Tidak Berhasil Menghapus Data";
    } 
?>