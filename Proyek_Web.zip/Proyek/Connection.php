<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbase = "sttsedunew";

    $conn = mysqli_connect($host, $user, $pass, $dbase);
	 session_start();
  $_SESSION['bahasa'] = 1;

?>