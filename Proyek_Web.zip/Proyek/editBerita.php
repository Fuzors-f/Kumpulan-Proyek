<?php
    require_once('Connection.php');
    $id = $_POST["id"];
    $judul = $_POST["judul"];
    $desc = $_POST["desc"];
    $tag = $_POST["tag"];
    $src = $_POST["src"];
    $tgl = date("Y-m-d H:i:s");

    $quwery = "SELECT * from BERITA_BAHASA WHERE berita_bahasa_id = $id";
    $list = $conn->query($quwery);
    $beritab = '';
    foreach ($list as $key => $value) {
        $beritab = $value['berita_id'];
    }
    $query2 = "UPDATE BERITA SET berita_foto='$src', berita_tgl='$tgl', WHERE agenda_id='$beritab'";
    if($id != ""){
        $querys = "UPDATE KONTEN_TAG SET TAG_ID= $tag WHERE KONTEN_PARENT= $beritab AND KONTEN_ID=2";
        $query = "UPDATE BERITA_BAHASA SET berita_id='$beritab', berita_judul='$judul', berita_deskripsi='$desc' WHERE berita_bahasa_id='$id'";
        if($conn->query($query) == true && $conn->query($querys) == true){
            echo "Berhasil Mengupdate Data";
        }else{
            echo "Tidak Berhasil Mengupdate Data";
        } 
    } else {
        echo "Tidak Berhasil Mengupdate Data";
    }  
?>