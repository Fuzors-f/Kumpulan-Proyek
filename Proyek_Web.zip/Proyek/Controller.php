
<?php 
   
    require_once("Connection.php");
    $tahun = $_POST['tahun'];
    $jenis = $_POST['jenis'];
    $bulan = $_POST['bulan'];
    $id = [];
   
    if($jenis == "0"){
        echo "<h1 style='font-size:20pt;'>Berita</h1>";
        echo "<hr style='border: 2px solid gray'><br>";
        
        $query = "select * from berita where year(berita_tanggal) = $tahun and month(berita_tanggal) = $bulan";
        $res = mysqli_query($conn, $query);
        foreach($res as $key=>$data){
            $id[Count($id)] = $data['berita_id'];
        }
        if(Count($id)>0){
            for ($i=0; $i<Count($id); $i++){
                $headerberitalain="";
                $res = mysqli_query($conn,"select * from berita_bahasa where berita_id='$id[$i]'");
                foreach($res as $key=>$data){
                    $headerberitalain=$data['berita_judul'];
                }
    
                echo "<a class='newsbox nounderline' href='HalamanBerita.php?urlpage=Berita&id=".$id[$i]."'>";
                echo "<h1 style='font-size:14pt; font-weight:bold;'>".$headerberitalain."</h1><br>";
                echo "</a>";
    
            }
        } else{
            echo "tidak ada berita pada bulan ini";
        }

    } else if($jenis== "1"){
        echo "<h1 style='font-size:20pt;'>Agenda</h1>";
        echo "<hr style='border: 2px solid gray'><br>";
        
        $query = "select * from agenda where year(agenda_tgl) = $tahun and month(agenda_tgl) = $bulan";
        $res = mysqli_query($conn, $query);
        foreach($res as $key=>$data){
            $id[Count($id)] = $data['agenda_id'];
        }
        if(Count($id)>0){
            for ($i=0; $i<Count($id); $i++){
                $headerberitalain="";
                $res = mysqli_query($conn,"select * from agenda_bahasa where agenda_id='$id[$i]'");
                foreach($res as $key=>$data){
                    $headerberitalain=$data['agenda_judul'];
                }
    
                echo "<a class='newsbox nounderline' href='HalamanAgenda.php?urlpage=Agenda&id=".$id[$i]."'>";
                echo "<h1 style='font-size:14pt; font-weight:bold;'>".$headerberitalain."</h1><br>";
                echo "</a>";
    
            }
        } else{
            echo "tidak ada agenda pada bulan ini";
        }
    } else{
        echo "<h1 style='font-size:20pt;'>Media</h1>";
        echo "<hr style='border: 2px solid gray'><br>";
        
        $query = "select * from media where year(media_tanggal) = $tahun and month(media_tanggal) = $bulan";
        $res = mysqli_query($conn, $query);
        foreach($res as $key=>$data){
            $id[Count($id)] = $data['media_id'];
        }
        if(Count($id)>0){
            for ($i=0; $i<Count($id); $i++){
                $headerberitalain="";
                $res = mysqli_query($conn,"select * from media_bahasa where media_id='$id[$i]'");
                foreach($res as $key=>$data){
                    $headerberitalain=$data['media_judul'];
                }
    
                echo "<a class='newsbox nounderline' href='HalamanMedia.php?urlpage=Media&id=".$id[$i]."'>";
                echo "<h1 style='font-size:14pt; font-weight:bold;'>".$headerberitalain."</h1><br>";
                echo "</a>";
    
            }
        } else{
            echo "tidak ada agenda pada bulan ini";
        }
    }
?>