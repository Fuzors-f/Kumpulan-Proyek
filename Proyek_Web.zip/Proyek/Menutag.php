<?php require_once("Connection.php"); 

    $query = "select * from tag";
    $id = [];
    $result  = mysqli_query($conn, $query);
    foreach($result as $key=> $data){
        $id[Count($id)] = $data['tag_id'];
    }

    $namatag = [];
    for($i=0; $i<Count($id); $i++){
        $index= $id[$i];
        $query2 = "select * from tag_bahasa where tag_id=$index";
        $res = mysqli_query($conn,$query2);
        foreach($res as $key=>$data){
            $namatag[Count($namatag)] = $data['tag_nama'];
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
 *{box-sizing: border-box}
body {font-family: "Lato", sans-serif;} 

/* Style the tab */
.tab {
  float: left;
  /*border: 1px solid #ccc;*/
/* background-color: #f1f1f1; */
  width: 30%;
  height: auto;
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 22px 16px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 0px 12px;
 /* border: 1px solid #ccc; */
/* background-color: red;*/
  width: 70%;
  height: 300px;
  
}
.responsive {
  width: 96%;
  height: 100%;
  z-index: 2;
  display: block;
}
.ov{
  position: absolute;
  width: 51%;
  height: 300px;
  background-color: rgba(0,0,0,0.6);
  box-shadow: 10px 10px 5px grey;
  color: white;
  padding-top :30px;
  padding-left : 30px;
  padding-right: 25px;
}
.nounderline {
  text-decoration: none !important
}
a:hover{
  color:blue;
}
</style>
</head>
<body>

<h2>Telusuri lebih lanjut tentang apapun yang ada</h2>
<p>Click on the buttons inside the tabbed menu:</p>

<div class="tab">
  <?php echo " <button class='tablinks' onclick='openTag(event, 0)' id='defaultOpen'>".$namatag[0]."</button>";
    for($i=1; $i<Count($namatag); $i++){
        echo " <button class='tablinks' onclick='openTag(event, ".$id[$i].")' >".$namatag[$i]."</button>";
    }
    ?>
</div>

<div id="0" class="tabcontent" >
        <h3 style="font-size:22pt; font-weight:bold;"><?php echo $namatag[0];?></h3>
        <div class="ov">
          <p style="font-weight:bold;font-size:18pt;">
            Ingin tahu lebih lanjut? Simak ulasan berikut 
          </p>
         <?php echo ' <a style="float:right;font-weight:bold; cursor:pointer;margin-top:30px;" href="HalamanTag.php?urlpage='.$namatag[0].'&id='.$id[0].'" class="nounderline">' ;?>
          SELENGKAPNYA</a>
        </div>
        <img src="Image/tech.jpg"  class="responsive">
    </div>
<?php for($i=1; $i<=Count($id); $i++){ ?>
    <div id="<?php echo $id[$i]; ?>" class="tabcontent" >
        <h3 style="font-size:22pt; font-weight:bold;"><?php echo $namatag[$i];?></h3>
        <div class="ov">
          <p style="font-weight:bold;font-size:18pt;">
            Ingin tahu lebih lanjut? Simak ulasan berikut 
          </p>
         <?php echo ' <a style="float:right;font-weight:bold; cursor:pointer;margin-top:30px;" href="HalamanTag.php?urlpage='.$namatag[$i].'&id='.$id[$i].'" class="nounderline">' ;?>
          SELENGKAPNYA</a>
        </div>
        <img src="Image/tech.jpg"  class="responsive">
    </div>
<?php }?>

<script>
function openTag(evt, tagName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tagName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
   
</body>
</html> 
