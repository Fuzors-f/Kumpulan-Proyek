<?php
  require_once("Connection.php");
  require_once("Sumber.php"); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .header img{
		position: sticky;
		z-index: 1;
        top: 0px;
        width: 100%;
        height: 60vh;
    }
    .rise{
        position: relative;
        top: -10vh;
    }
	.judul{
        position: relative;
        text-align: center;
        top: -40vh;
		z-index: 2;
        color: white;
        font-size: 50pt;
    }
    .path{
        color: white;
        text-align: center;
        font-size: 20pt;
    }

</style>
<body>
    <?php include("Header.php"); ?>
    <?php include("minioverlay.php"); ?>
    <div class="container" style="margin-top:20vh;margin-bottom:40px;">
        <div class="row">
            <?php $query="SELECT * FROM DOSEN";
                $list = $conn->query($query);
                foreach ($list as $key => $value) {
            ?>
            <div class="col s12 l4">
                <div class="card horizontal">
                    <div class="card-image">
                        <img src="Image/profile.jpg" height="100" width="100">
                    </div>
                    <div class="card-stacked">
                        <div class="card-content">
                        <p><?= $value['dosen_nama']?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php     
                }
            ?>
        </div>
    </div>
    <?php include("Footer.php"); ?>
</body>
</html>
