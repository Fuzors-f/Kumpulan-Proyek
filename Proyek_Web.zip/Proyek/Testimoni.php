<?php
    require_once("Connection.php");
?>
<html>
    <head>
        <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/Proyek.css">
        <script src="jquery/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="materialize/js/materialize.min.js"></script>
        <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
    </head>
    <body>
        <?php include("Header.php"); ?>
        <?php include("minioverlay.php"); ?>
        <div class="container" id="cont" style="margin-top: 30vh;padding-left: 8vw;">
        </div>
        <div style="position:relative;width:100%;">
            <?php include("footer.php"); ?>
        </div>
        
    </body>
    <script>
        $('#cont').load("ListTestimoni.php");
        function testiKlik(id){
            $('#cont').html("");
            $('#cont').load("detilTestimoni.php?",{id:id});
        }
    </script>
</html>