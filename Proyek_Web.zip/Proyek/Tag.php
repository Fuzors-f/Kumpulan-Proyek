<?php
    require_once('Connection.php');
    require_once('Sumber.php');
    
    $action = 0;
    if(isset($_REQUEST['btnEdit'])){
        $dataid = $_GET['btnEdit'];
        $action = 1;
        $query = "SELECT * FROM TAG WHERE TAG_ID='$dataid'";
        $query2 = "SELECT * FROM TAG_BAHASA WHERE TAG_ID='$dataid'";

        $list = $conn->query($query);
        $list2 = $conn->query($query2);
    }

    if(isset($_REQUEST['btnDelete'])){
        $dataid = $_POST['btnDelete'];
        $action = 2;
        $query = "SELECT * FROM TAG WHERE TAG_ID='$dataid'";
        $query2 = "SELECT * FROM TAG_BAHASA WHERE TAG_ID='$dataid'";

        $list = $conn->query($query);
        $list2 = $conn->query($query2);
    }

    if(isset($_REQUEST['up'])){
        $target_dir = "Image/"; //<- ini folder tujuannya
        $target_file = $target_dir. basename($_FILES["gambar"]["name"]); //murni mendapatkan namanya saja tanpa path nya 
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if($file_type !="jpg" && $file_type !="png"){
            echo "tipe file hanya jpg dan png saja";
        } else if($_FILES["gambar"]["size"] > 500000){
            echo "file size terlalu besar";
        } else if(file_exists($target_file)){
            echo "file sudah ada";
        }
        else{
            if(move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)){
                echo "file ".basename($_FILES["gambar"]["name"])." terupload";
            }
        } 
      
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .tag label{
        position: absolute;
        top: -10px;
        font-size: 20px;
    }

    .tag button:hover{
        padding: 0px 50px;
    }

    .judul{
        text-align: left;
        font-size: 18px;
        color: grey;
        font-weight: bold;
    }
    .preview{
        width: 100px;
        height: 100px;
        border: 1px solid black;
        margin: 0 auto;
        background: white;
    }

    .preview img{
        display: none;
    }
</style>
<body>
<?php if($action == 0){ ?>
    <div class="row tag">
        <div class="col s12">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>CRUD Tag --- CREATE</h2>
                </div>
                <div class="card-content">
                    <div class="input-field">
                    <div class="judul">Judul Tag <i class="material-icons left" style="color: black;">title</i></div>
                        <input type="text" name="judulTxt" id="JudulTxt">
                    </div><br>
                    
                    <button class="waves-effect waves-light btn-large" type="submit" value="submit" id="btnInsert">Submit <i class="material-icons right">send</i></button>
                    <br>
                </div>
            </div>
        </div>
    </div>
    <div style="overflow: auto;width: 100vw;height: 100vh;" class="table"></div>
<?php 
} 
else if($action == 1){ 
    foreach ($list as $key => $value) {
        foreach ($list2 as $key => $value2) {
?>
    <div class="row berita">
        <div class="col s12">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>CRUD Tag --- UBAH</h2>
                </div>
                <div class="card-content">
                    <div class="input-field">
                    <div class="judul">Judul Tag <i class="material-icons left" style="color: black;">title</i></div>
                        <input type="text" name="judulTxt" id="JudulTxt" value="<?= $value2['tag_nama']?>">
                    </div><br>
                    
                    <button class="waves-effect waves-light btn-large" type="submit" value="<?= $dataid ?>" id="btnUpdate">Update <i class="material-icons right">send</i></button>
                    <button class="waves-effect waves-light btn-large" type="submit" id="btnCancel"><a class="nounderline" href="admin.php">Cancel <i class="material-icons right">send</i></a></button>
                   
                </div>
            </div>
        </div>
    </div>
<?php        
    }}} else{ 
        foreach ($list2 as $key => $value) {       
?>
    <div class="row berita">
        <div class="col s12">
            <div class="card">
                <div class="card-action red white-text">
                    <h2>CRUD Tag --- HAPUS</h2>
                </div>
                <div class="card-content">
                <div class="judul">Apakah Anda yakin Menghapus Data dengan: <i class="material-icons left" style="color: black;">title</i></div>
                    <div class="judul">Judul Tag <i class="material-icons left" style="color: black;">title</i></div>
                    <input disabled type="text" name="judulTxt" id="JudulTxt" value="<?= $value['tag_nama']?>">
                    <button class="waves-effect waves-light btn-large" type="submit" value="<?= $dataid ?>" id="btnDelete">Delete <i class="material-icons right">send</i></button>
                    <button class="waves-effect waves-light btn-large" type="submit" id="btnCancel"><a class="nounderline" href="admin.php">Cancel <i class="material-icons right">send</i></a></button>
                </div><br>
                <br>
            </div>
        </div>
    </div>
    <?php }}?>
</body>
</html>
<script>
    $('.table').load('tagTable.php');
    $(document).ready(function(){
        $('select').formSelect();
        $("#btnInsert").click(function (){
            let judul = $('#JudulTxt').val();

            $.ajax({
                url: "insertTag.php",
                method: 'post',
                data: {
                    judul : judul
                },
                success: function(result){
                    $('.table').load('tagTable.php');
                    window.location.pathname ="proyek/admin.php"; 
                    alert(result);
                }
            });
        });

        $("#btnUpdate").click(function (){
            let id = $(this).val();
            let judul = $('#JudulTxt').val();
            let bhs = $('#CBbahasa').val();

            $.ajax({
                url: "editTag.php",
                method: 'post',
                data: {
                    id : id,
                    judul : judul,
                    bhs : bhs
                },
                success: function(result){
                    $('.table').load('tagTable.php');
                    window.location.pathname ="proyek/admin.php";
                    alert(result);
                }
            });
        });

        $("#btnDelete").click(function (){
            let id = $(this).val();
            $.ajax({
                url: "deleteTag.php",
                method: 'post',
                data: {
                    id : id  
                },
                success: function(result){
                    window.location.pathname ="proyek/admin.php";
                    alert(result);
                }
            });
        });

        $("#btnCancel").click(function (){
            window.location.pathname ="proyek/admin.php";
        });
    });
</script>
