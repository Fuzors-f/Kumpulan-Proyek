<?php
    require_once("Connection.php");
    require_once("Sumber.php");
  //  session_start();
    if(isset($_POST['logout']) || isset($_POST['back'])){
        $_SESSION['userlogin'] = "";
        $_SESSION['statlogin'] = 0;
        header("location: login.php");
    }
    $userlogin ='';
    $status ='';
    if(isset($_SESSION['userlogin'] )&& isset($_SESSION['statlogin'])){
        $userlogin = $_SESSION['userlogin'];
        $status = $_SESSION['statlogin'];
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>
    <style>
        .col{
            margin: 10px;
            text-align: center;
        }

        h1{
            color: white;
        }
    </style>
    <body>
        <?php if($status == 1){?>
        <div class="col s12 #ef5350 red lighten-1"><h1>Selamat datang, <?=$userlogin?></h1>
        <form action="#" method="post">
            <button class="col s3 offset-s3 waves-effect waves-light btn-large" id="btnLogout" type="submit" value="submit" name="logout">Logout <i class="material-icons right">arrow_back</i></button>  
        </form>
        </div>
        
        <div class="container">
        <div class="row">
            <div class="col s12">
                <button class="col s6 waves-effect waves-light btn-large" id="btnAgenda" type="submit" value="submit">Agenda <i class="material-icons right">arrow_downward</i></button>
                <div class="container">
                    <div class="row">
                    <div class="col s12">
                        <div class="middleside"></div> 
                    </div>
                </div>
            </div>
            <button class="col s6 push-s2 waves-effect waves-light btn-large" id="btnBerita" type="submit" value="submit">Berita <i class="material-icons right">arrow_downward</i></button>   
                <div class="container">
                    <div class="row">
                        <div class="col s12">
                            <div class="middleside2"></div> 
                        </div>
                    </div>
                </div>
            <button class="col s6 push-s4 waves-effect waves-light btn-large" id="btnMedia" type="submit" value="submit">Media <i class="material-icons right">arrow_downward</i></button>   
            <div class="container">
                    <div class="row">
                        <div class="col s12">
                            <div class="middleside3"></div> 
                        </div>
                    </div>
                </div>
            <button class="col s6 push-s6 waves-effect waves-light btn-large" id="btnTag" type="submit" value="submit">Tag <i class="material-icons right">arrow_downward</i></button>   
            <div class="container">
                    <div class="row">
                        <div class="col s12">
                            <div class="middleside4"></div> 
                        </div>
                    </div>
                </div>
        </div>
    </div>
    </div>
    <?php } else{ ?>
        <div class="col s12 #ef5350 red lighten-1"><h1>Maaf Anda belum Login</h1>
        <form action="#" method="post">
        <button class="col s3 offset-s3 waves-effect waves-light btn-large" id="btnAgenda" type="submit" value="submit" name="back">Back to Login Form <i class="material-icons right">arrow_back</i></button>  
        </form>
        </div>
    <?php } ?>
</body>
</html>
<script>
var ctr = 0;
    $(document).ready(function(){
        $("#btnAgenda").click(function (){
            ctr++;
            if(ctr % 2 == 0){
                $(".middleside").html("");
            }else{
                $(".middleside").load("Agenda.php");
                $(".middleside2").html("");
                $(".middleside3").html("");
                $(".middleside4").html("");
            }
        });

        $("#btnBerita").click(function(){
            ctr++;
            if(ctr % 2 == 0){
                $(".middleside2").html("");
            }else{
                $(".middleside2").load("Berita.php");
                $(".middleside").html("");
                $(".middleside3").html("");
                $(".middleside4").html("");
            }
        });

        $("#btnMedia").click(function(){
            ctr++;
            if(ctr % 2 == 0){
                $(".middleside3").html("");
            }else{
                $(".middleside3").load("Media.php");
                $(".middleside").html("");
                $(".middleside2").html("");
                $(".middleside4").html("");
            }
        });

        $("#btnTag").click(function(){
            ctr++;
            if(ctr % 2 == 0){
                $(".middleside4").html("");
            }else{
                $(".middleside4").load("Tag.php");
                $(".middleside").html("");
                $(".middleside2").html("");
                $(".middleside3").html("");
            }
        });
    });
</script>