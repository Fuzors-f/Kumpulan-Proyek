<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>
<style>
  .grey-text{
    text-transform: none;
  }
</style>
<body>
    <footer class="page-footer" style="background-color: rgba(0,0,0,0.8)">
      <div class="container">
        <div class="row">
          <div class="col l6 s12">
            <h3 class="white-text">SOSIAL MEDIA</h3>
            <div class="icon">
              <a href="https://www.instagram.com/haloistts/"><img src="Image/instagram.png" width="50px" height="50px"></a>
              <a href="https://www.facebook.com/istts.page/"><img src="Image/facebook.png" width="48px" height="48px"></a>
            </div><br>
            <p class="grey-text text-lighten-4">Ikuti Instagram dan Facebook kami untuk mendapatkan informasi seputar kampus kami.</p>
          </div>
          <div class="col l4 offset-l2 s12">
            <h3 class="white-text">LAYANAN MAHASISWA</h3>
            <ul class="nounderline">
              <li><a class="grey-text text-lighten-3 nounderline" href="http://sim.istts.ac.id/" >Sistem Informasi Mahasiswa (SIM)</a></li>
              <li><a class="grey-text text-lighten-3 nounderline" href="https://eclass.istts.ac.id/">E-Class</a></li>
            </ul>
          </div>
          <div class="col l4 offset-l2 s12">
            <h3 class="white-text">Pembuat</h3>
            <ul class="nounderline">
              <li>Albert Y. W.</li>
              <li>Fendy S. G.</li>
              <li>Michael S. W.</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-copyright"  style="background-color: rgba(0,0,0,0.6)">
        <div class="container">
        Copyright © www.istts.ac.id 2017 - Proyek Aplin
        <a class="grey-text text-lighten-4 right nounderline" href="https://istts.ac.id/">iSTTS</a>
      </div>
      </div>
    </footer>                    
</body>
</html>   
                                                            
        