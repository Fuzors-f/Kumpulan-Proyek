<?php
    require_once("Connection.php");
  //  session_start();
    
    $id = $_POST["id"];
    $bahasaid ="";
    if(isset($_SESSION['bahasa'])){
        $bahasaid = $_SESSION['bahasa'];
    }

   
        $query ="SELECT berita_deskripsi from berita_bahasa WHERE berita_id = $id and bahasa_id=$bahasaid";
        $sql = mysqli_query($conn,$query);
        $result = mysqli_fetch_array($sql);

       
        $isi = $result[0];
        echo $isi;
?>