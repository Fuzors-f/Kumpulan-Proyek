<?php
    require_once("Connection.php");
?>
<style>
    .oek:hover{
        cursor:pointer;
       
    }
    .oke:hover{
        background-color:gray;
        color: white;
    }
</style>
<div class="row"> 
    <?php
        $query=mysqli_query($conn,"SELECT * from testimoni");
        while($row = mysqli_fetch_assoc($query)){
            echo "<div class='col s12 l4 oek' onclick='testiKlik(".$row['testimoni_id'].")'>".
                    "<div class='card horizontal'>".
                        "<div class='card-image'>".
                            "<img src='Image/profile.jpg' height='100' width='100'>".
                        "</div>".
                        " <div class='card-stacked oke'>".
                            "<div class='card-content '>".
                                "<p>".$row['testimoni_nama']."</p>".
                            "</div>". 
                        "</div>".
                    "</div>".
                "</div>"; 
        }

    ?>
</div>
<!-- <a href="#" data-target="slide-out" class="sidenav-trigger btn">Side nav demo</a>

        <ul id="slide-out" class="sidenav">
        <li><a href="#!" class="Homebtn"><i class="material-icons"></i>Home</a></li>
        <li><div class="divider"></div></li>
        <li><a class="subheader">Subheader</a></li>
        <li><a class="waves-effect" href="#!">Third Link With Waves</a></li>
        </ul>
<a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
<script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.sidenav');
            var instances = M.Sidenav.init(elems, options);
        });
        $(document).ready(function(){
            $('.sidenav').sidenav();
            $('.Homebtn').click(function(){
                window.location="index.php";
            })
        });
</script> -->