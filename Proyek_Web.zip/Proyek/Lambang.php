<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
</head>
<body>
    <?php include("Header.php"); ?>
    <?php include("minioverlay.php"); ?>
    <div class="container" style="margin-top: 25vh;padding: 1vh;">
        <div class="row">
                <img class="responsive-img materialboxed" width="300" src="Image/logo2.png" style="margin: auto;"><br> <br>
                <div style="margin:auto;font-size:50pt; margin-left:27vw;"><h1>Arti Lambang iSTTS</h1></div>
        </div> 
        <div class="row">
            <div style="margin:auto; border-radius:20px; border: 2px solid black; padding:20px;">
                <p>Mempunyai arti sebagai berikut: </p>
                <p>1. Lingkaran di tengah dengan simbol 3 unsur elektroda, menunjukkan bahwa bidang kegiatan yang dipelajari hampir seluruhnya oleh unsur-unsur tersebut.</p>
                <p>2. Orbit yang berjumlah 3 buah melingkari 3 unsur elektroda melambangkan Tri Dharma Perguruan Tinggi menyelubungi seluruh aktivitas di STTS.</p>
                <p>3. Elektron sejumlah 6 buah pada orbit mempunyai arti :</p>
               <p> <span style="padding-left:15px;">• Memahami, menghayati, dan mengamalkan Pancasila.</span></p>
               <p> <span style="padding-left:15px;">• Bermental tinggi serta menjadi manusia yang integral dan mandiri.</span></p>
               <p> <span style="padding-left:15px;">• Menjadi manusia yang intelektual sehingga bisa menjunjung tinggi martabat bangsa Indonesia.</span></p>
               <p> <span style="padding-left:15px;">• Mampu menghayati keahliannya serta dapat mengambil kesimpulan praktis dari teori-teori yang dipelajari dalam bidangnya.</span></p>
               <p> <span style="padding-left:15px;">• Berbudaya dan berjiwa sosial.</span></p>
               <p> <span style="padding-left:15px;">• Dengan keahliannya bisa berfungsi efektif bagi masyarakat, bangsa, dan negara.</span></p>
               <p>4. Warna dasar kuning mempunyai makna keagungan dan penyuluhan</p>

            </div>
        </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>
<script>
    
     var gallery = document.querySelectorAll(".materialboxed");
     M.Materialbox.init(gallery,{}); 
</script>