<?php
    require_once('Connection.php');
    require_once("Sumber.php");
    $agendaid = [];
    $judulagenda =[];
    $querys = "select * from agenda_bahasa where bahasa_id = 1";
    $rs = mysqli_query($conn, $querys);
    foreach($rs as $key=>$data){
        $agendaid[Count($agendaid)] = $data['agenda_id'];
        $judulagenda[Count($judulagenda)] = $data['agenda_judul'];
    }

?>              

<option value="-1">Klik di sini jika mau translate</option>
    <?php
    for($i=0; $i<Count($agendaid); $i++){
    ?>
    <option value="<?= $agendaid[$i]?>"><?= $judulagenda[$i]?></option>
<?php } ?> 

