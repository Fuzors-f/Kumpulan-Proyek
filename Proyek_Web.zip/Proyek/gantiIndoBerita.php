<?php
    $isi = "LOL";
    echo $isi;
?>