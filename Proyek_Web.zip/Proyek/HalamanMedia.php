<?php
    require_once("Connection.php");
  //  session_start();
    $bahasa =0;
    if(isset($_SESSION['bahasa'])){
        $bahasa = $_SESSION['bahasa'];
    }

    $id = $_GET['id'];
    $tanggal ='';
    $judul ="";
    $isi ="";
    $foto ="";
   $sumbertajuk ="";
    $halaman = "";
    $sumbertanggal = "";
    $query = "select * from media where media_id='$id'";
    $res = mysqli_query($conn,$query);
    foreach($res as $key=>$data){
      $tanggal =$data['media_tanggal'];
      $foto = $data['media_foto'];
      $sumbertajuk = $data['media_sumber_tajuk'];
      $halaman = $data['media_sumber_hal'];
      $sumbertanggal = $data['media_sumber_tgl'];
    }
    $query2 = "select * from media_bahasa where media_id='$id' and bahasa_id=$bahasa";
    $res2 = mysqli_query($conn,$query2);
    foreach($res2 as $key=>$data){
        $judul =$data['media_judul'];
        $isi = $data['media_deskripsi'];
    }

    $beritaid =[];
    $beritafoto=[];
    $query = "select * from media order by media_tanggal desc";
    $res = mysqli_query($conn,$query);
    foreach($res as $key=>$data){
        if($data['media_id'] != $id){
             $beritaid[Count($beritaid)] = $data['media_id'];
             $beritafoto[Count($beritafoto)] = $data['media_foto'];
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Proyek.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="materialize/js/materialize.min.js"></script>
    <style>
        .style8{
            border-top: 2px solid #8c8b8b;
	        border-bottom: 2px solid #fff;
            margin-bottom: 40px;
      }
      .newsbox{
          width:250px;
          height:200px;
          padding-left: 10px;
          background-color:white; 
          padding-top:2px;
          margin-left: 25px;
          margin-top: 10px;
          margin-bottom: 10px;
          color: black;
      }
      .imgnews{
          width:200px;
          height:90px;
      }
      .ktkberita{
        width:250px;
         background-color:white; 
         height:60px;color:black; 
         margin-left: 25px;
         margin-bottom:15px;
         margin-top:10px;
         text-align:center;
         font-size:15pt;
         font-weight:bold;
         padding:15px;
      }
    </style>
</head>
<body>
   
    <div style=" background-color:rgb(243,243,243);">
        <?php include("Header.php"); ?>
        <?php include("minioverlay.php"); ?>
        <div class="container" style="margin-top:20vh;margin-bottom:40px;margin-left:20vw;">
            <div class="row">
                <div class="col s5 push-s7" >
                    <div class="ktkberita">MEDIA LAIN</div>
                    <?php 
                         echo    "<a class='ktkberita nounderline' style='font-size:11pt' href='ArsipBerita.php?urlpage=Arsip'>Lihat arsip </a>";
                        for($i=0; $i<3; $i++){
                         echo    "<a class='newsbox nounderline' href='HalamanMedia.php?urlpage=Media&id=".$beritaid[$i]."'>";
                    
                    ?>
                        <h1><div style="width:180px;font-size:10pt;font-weight:bold;">
                        <?php
                            $headerberitalain="";
                            $res = mysqli_query($conn,"select * from media_bahasa where media_id='$beritaid[$i]' and bahasa_id=$bahasa");
                            foreach($res as $key=>$data){
                                $headerberitalain=$data['media_judul'];
                            }
                        
                        echo $headerberitalain; ?>...</div></h1>
                        <?php  echo "<img src='".$beritafoto[$i]."' class='imgnews'>"?>
                    <?php echo "</a>"; 
                            }
                    ?>
                </div>
                <div class="col s7 pull-s5"style="background-color:white;padding:15px;">
                    <h1><?php echo $judul; ?></h1>
                    <hr class="style8">
                    <h2 style="font-size:12pt;font-style:italic;"><?php echo $tanggal; ?></h2>
                    <?php if($foto !=""){
                        echo  "<img src='".$foto."' style='width:800px;margin-top:25px;margin-bottom:20px;'>";
                    } ?> <br>
                    <div class="isiMedia">
                        <?php echo $isi ?>
                    </div>
                    <br>
                   <span><?php 
                        if($sumbertajuk != "" && $halaman !="0" ){
                            echo "(".$sumbertajuk.",".$sumbertanggal.":".$halaman.")";
                        }
                    ?></span>
                </div>
            </div>
        </div>
        <?php include("Footer.php"); ?>
    </div>
    
</body>
</html>