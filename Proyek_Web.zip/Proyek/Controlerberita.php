<?php
    require_once("Connection.php");
    $beritaid =[];
    $beritafoto=[];
    $totallitas =[];
    $query = "select * from berita order by berita_tanggal desc";
    $res = mysqli_query($conn,$query);
    $totallitas = $res;
   
    foreach($res as $key=>$data){
      $beritaid[Count($beritaid)] = $data['berita_id'];
      $beritafoto[Count($beritafoto)] = $data['berita_foto'];
    }
    // $qu = "SELECT 'ABCDEF12345' FROM DUAL";
    // $ha ="";
    // $co =$conn->query($qu);
    // foreach ($co as $key => $value) {
    //   # code...
    //   $ha = $value['ABCDEF12345'];
    // }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
   <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Proyek.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
       * override position and transform in 3.3.x */
        .carousel-inner .item.left.active {
                transform: translateX(-33%);
        }
        .carousel-inner .item.right.active {
                 transform: translateX(33%);
        }

        .carousel-inner .item.next {
                transform: translateX(33%);
        }
        .carousel-inner .item.prev {
                 transform: translateX(-33%);
        }

        .carousel-inner .item.right,
        .carousel-inner .item.left { 
                transform: translateX(0);
        }


      .carousel-control.left,.carousel-control.right {background-image:none;}

      .style8{
        border-top: 2px solid #8c8b8b;
	      border-bottom: 2px solid #fff;
      }
      .btnberita{
        margin-left:25vw; width: 400px; font-size: 30pt; margin-bottom: 3vh;
        margin-top: 1vh;
        background-color: white;
        color: black;
        border: 4px solid gray;
        border-radius: 25px;
      }
      .btnberita:hover{
        box-shadow: 10px 10px 5px black;
        cursor: pointer;
        background-color: gray;
        color: white;
      }

      .glyphicon{
          color: black;
      }
      @media screen and (max-width: 800px){
        .btnberita{
          margin-left:-0.2vw;
        }
      }
    </style>
</head>
<body>
<div class="carousel slide" id="myCarousel1" style="height:600px">
  <div class="carousel-inner">
     <?php
        $res = mysqli_query($conn,"SELECT 'ABCDEF12345' from DUAL");
        $judul="";
        $isi="";
        foreach($res as $key=>$data){
            $judul=$data['ABCDEF12345'];
        } ?> 
    <div class="item active"style="height:850px;">
      <div class="col-md-4"><img src="<?php echo "hai";?>" width="350px;" class="img-responsive" onerror="this.onerror=null; this.src='Image/non.jpg'"><div style="height:100px;"><h1 style="font-size:25pt;"><?php echo $judul; ?></h1></div><hr class="style8">
        <?php 
            echo "<a href='HalamanBerita.php?urlpage=Berita&id=".$beritaid[0]."' style='color:black;padding-left:105px;'>SELENGKAPNYA</a>";
        ?>
      </div>
    </div>


    <!-- <div class="item active"style="height:850px;">
      <div class="col-md-4"><img src="<?php echo $beritafoto[0];?>" width="350px;" class="img-responsive" onerror="this.onerror=null; this.src='Image/non.jpg'"><div style="height:100px;"><h1 style="font-size:25pt;"><?php echo $ha?></h1></div><hr class="style8">
        <?php 
            echo "<a href='HalamanBerita.php?urlpage=Berita&id=".$ha."' style='color:black;padding-left:105px;'>SELENGKAPNYA</a>";
        ?>
      </div>
    </div>  -->

    <?php for($i=1; $i<=5; $i++){
        $res = mysqli_query($conn,"select * from berita_bahasa where berita_id =$beritaid[$i]");
        $judul="";
        $isi="";
        foreach($res as $key=>$data){
            $judul=$data['berita_judul'];
        }?>
   
    <div class="item "style="height:850px;">
      <div class="col-md-4" ><img src="<?php echo $beritafoto[$i];?>" width="350px;" class="img-responsive" onerror="this.onerror=null; this.src='Image/non.jpg'"><div style="height:100px;"><h1 style="font-size:25pt;"><?php echo $judul ?></h1></div><hr class="style8">
       <?php 
            echo "<a href='HalamanBerita.php?urlpage=Berita&id=".$beritaid[$i]."' style='color:black;padding-left:105px;'>SELENGKAPNYA</a>";
        ?>
      </div>
    </div>
    <?php }?>
  </div>
  <a class="left carousel-control" href="#myCarousel1" data-slide="prev" style="margin-top:-30px;"><i class="glyphicon glyphicon-chevron-left"></i></a>
  <a class="right carousel-control" href="#myCarousel1" data-slide="next" style="margin-top:-30px;"><i class="glyphicon glyphicon-chevron-right"></i></a>
</div>
<div>
        <input type="button" value="Lihat Arsip" class="btnberita">

<div>
</body>
</html>
<script type="text/javascript"> 
     $('#myCarousel1').carousel({
          interval: 10000
    })

    $('.carousel .item').each(function(){
    var next = $(this).next();
    if (!next.length) {
        next = $(this).siblings(':first');
    }
    next.children(':first-child').clone().appendTo($(this));
    
    if (next.next().length>0) {
        next.next().children(':first-child').clone().appendTo($(this));
    }
    else {
        $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
    }
    });

    $(".btnberita").click(function(){
      document.location.href = 'ArsipBerita.php?urlpage=Arsip';
    });
 </script> 