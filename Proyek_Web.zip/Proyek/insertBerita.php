<?php
    require_once("Connection.php");
    
    $judul = $_POST["judul"];
    $desc = $_POST["desc"];
    $tmpbhs = $_POST["bhs"];
    $tag = $_POST["tag"];
    $src = $_POST["src"];
    $tgl = date("Y-m-d H:i:s");
    $bhs = (int)$tmpbhs;
    $sourceid = $_POST['sourceid'];
    $translate = (int)$sourceid;

    $konten = 2;
    if($translate == -1){
        $query2 = "INSERT INTO berita VALUES('','$src','$tgl',1)";
        if($conn->query($query2)== true){
            $id ="";
            $res  = mysqli_query($conn, "select * from berita order by berita_tanggal");
            foreach($res as $key=>$data){
                $id = $data['berita_id'];
            }
            if($id != ""){
                if($tag != "-1"){
                    $query = "INSERT INTO berita_bahasa VALUES('',$id,'$judul','$desc',$bhs)";
                    $query3 = "INSERT INTO konten_tag VALUES($konten, $id, $tag)";
                    if($conn->query($query) == true && $conn->query($query3) == true){
                        echo "Berhasil Menambahkan Data";
                    }else{
                        echo "Tidak Berhasil Menambahkan Data";
                    } 
                } else{
                    $query = "INSERT INTO berita_bahasa VALUES('',$id,'$judul','$desc',$bhs)";
                    if($conn->query($query) == true ){
                        echo "Berhasil Menambahkan Data";
                    }else{
                        echo "Tidak Berhasil Menambahkan Data";
                    } 
                }
            } else {
                echo "Tidak Berhasil Menambahkan Data";
            }
        } else {
            echo "Tidak Berhasil Menambahkan Data";
        }

    }else{
        $query5 = "SELECT * FROM berita_BAHASA WHERE berita_ID=$translate and bahasa_id= 2";
        $list = $conn->query($query5);
        $rowcount = mysqli_num_rows($list);
        if($rowcount > 0){
            echo "Data Translate sudah ada";
        }else{          
            $query = "INSERT INTO berita_bahasa VALUES('',$translate,'$judul','$desc',$bhs)";
            if($conn->query($query) == true){
                echo "Berhasil Mentranslate Data";
            }else{
                echo "Tidak Berhasil Mentranslate Data";
            } 
        }
    }
    
?>