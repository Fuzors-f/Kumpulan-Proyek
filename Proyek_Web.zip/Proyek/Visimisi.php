<!DOCTYPE html>
<html lang="en">
<head>
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Proyek.css">
    <script src="jquery/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="materialize/js/materialize.min.js"></script> 
    <title>Institut Sains dan Teknologi Terpadu Surabaya</title>  
</head>
<body>
    <?php include("Header.php"); ?>
    <?php include("minioverlay.php"); ?>
    <div class="container" style="margin-top: 25vh;padding: 1vh;margin-left:12vw;width:70vw;">
        <div style="margin-left:45%;margin-bottom:4vh;"><h1 style="font-size:30pt;">Visi dan Misi</h1></div>
        <div class="row">
            <div class="col s6" style="text-align:center;">
                <h1 style="font-size: 25pt"> Visi</h1>
                <hr>
                <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;font-size: 14pt">
                Pada Tahun 2022, STTS menjadi perguruan tinggi unggulan bidang sains, teknologi, dan desain
                yang mampu bersaing di tingkat Asia Tenggara, dengan mengedepankan kualitas, inovasi, dan nilai-nilai
                keindonesiaan
                </p>
            </div>
            <div class="col s6" style="text-align:center;">
                <h1 style="font-size: 25pt"> Misi</h1>
                <hr>
                <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;"><span style="font-size: 15pt">1.</span>
                        Memberikan materi pendidikan dan pengajaran terbaik di bidang sains, teknologi, dan desain, 
                        dalam sistem tata kelola organisasi yang efisien disesuaikan dengan situasi dan 
                        kondisi kebutuhan  dan perkembangan sosial, ekonomi,  dan budaya masyarakat Indonesia.
                </p>
                <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;"><span style="font-size: 15pt">2.</span>
                    Bekerja sama dengan berbagai perguruan tinggi dan industri di Indonesia,  melakukan penelitian 
                    terapan bidang sains, teknologi, dan desain, disesuaikan dengan situasi, kondisi,  kebutuhan, dan perkembangan masyarakat Indonesia. 
                </p>
                <p style="text-align: justify;text-indent: 3vw;padding-right: 5vw;padding-left: 5vw;"><span style="font-size: 15pt">3.</span>
                    Menyediakan berbagai solusi inovatif dan unggul berbasis sains, teknologi, dan desain bagi berbagai masalah sosial, ekonomi,  dan budaya, 
                    khususnya dalam  menghadapi pasar masyarakat ekonomi ASEAN dan Trans Pacific Partnership (TPP).
                </p>
            </div>
        </div>
    </div>
    <?php include("Footer.php"); ?>
</body>
</html>